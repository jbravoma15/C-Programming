/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa2                  *
************************/

#include "Graph.h"
#include "List.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int score = 0;
    //Testing NewGraph(), GetOrder(), GetSize(), getParent(), and getDist()
    Graph G = NULL;
    int n = 35;         // Set order to 35
    G = newGraph(n);  
    printf("Testing Constructor and First 5 Access Functions()\n");
    

    if(getOrder(G) == 35){
        printf("Passed:Order is correct: 35 \n"); // output for this is 35
        score++;
    }else{
        printf("Test Failed: Order is not correct: %d \n", getOrder(G)); 
    }
    if(getSize(G) == 0){
        printf("Passed:Size is correct: %d \n",getSize(G)); // output for this is 0
        score++;
    }else{
        printf("Test Failed: Size is not correct: %d \n",getSize(G));
    }
    if(getSource(G) == NIL){
        printf("Passed:Source is Set to NIL \n"); // output for this is NIL
        score++;
    }else{
        printf("Test Failed: Source is not Set to NIL \n");
    }
    if(getParent(G, 1) == NIL){
        printf("Passed:Parent is set to NIL \n"); // output for this is NIL
        score++;
    }else{
        printf("Test Failed: Parent is not NIL \n");
    }
    if(getDist(G, 1) == INF){
        printf("Passed: Dist i set to INF\n"); // output for this is INF
        score++;
    }else{
        printf("Test Failed: Dist is not INF\n");
    }
    

    printf("Following constructor and access results scored %d/5 \n", score);



    //testing  Manipulation functions
    printf("\n");
    score = 0;  //reset test score
    //test 1 for MakeNull
    printf("Testing Manipulaiton Functions()\n");
    makeNull(G);
    if (getSource(G) == NIL && getParent(G, 1) ==  NIL && getSize(G) == 0){
        printf("Passed: Graph is set to orginal (no edge) state\n");
        score++;
    }else{
        printf("Test Failed: Graph is not set to orginal (no edge) state\n");
        printf("%d",getSource(G));
        printf("%d",getParent(G, 1));
        printf("%d",getSize(G));
    }
    

    //test for AddEdge  
    n = 5;
    G = newGraph(n);
    addEdge(G, 1, 4);
    addEdge(G, 1, 3);
    addEdge(G, 3, 2);
    addEdge(G, 2, 1);
    if(getSize(G) == 4){
        printf("Passed: addEdge added successfully\n");
        printGraph(stdout, G);  //Testing PrintGraph
        score++;
    }else{
        printf("Test Failed: addEdge not added successfully\n");
        }

    //test for Add Arc
    n = 6;
    G = newGraph(n);
    addArc(G, 1, 2);
    addArc(G, 2, 3);
    addArc(G, 3, 1);
    addArc(G, 4, 5);
    addArc(G, 5, 4);

    if(getSize(G) == 5){
        printf("Passed: addArc added successfully\n");
        printGraph(stdout, G);  //Testing PrintGraph
        score++;
    }else{
        printf("Test Failed: AddArc not added successfully\n");
        }

    //test for BFS
    n = 5;
    G = newGraph(n);
    addEdge(G, 1, 2);
    addEdge(G, 1, 4);
    addEdge(G, 3, 4);
    addEdge(G, 2, 3);
    BFS(G, 1);
    if(getParent(G, 3) == 2 && getParent(G, 3) && getDist(G, 3) == 2){
        printf("Passed: BFS traversal successful\n");
        printGraph(stdout, G);  //Testing PrintGraph
        score++;
    }else{
        printf("Test Failed: BFS traversal not successful\n");
    }

    printf("Following Manipulation results scored %d/4 \n", score);
    

    score = 0;
    //testing free graph
    freeGraph(&G);

   

 
}
