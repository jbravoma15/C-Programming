
/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa2                  *
************************/

#include "Graph.h"
#include <stdlib.h>
#include <stdio.h>

typedef enum { WHITE, GRAY, BLACK } Color;

typedef struct GraphObj {
    List *adj;  
    int *color;      
    int *parent;     
    int *distance;   
    int order;       
    int size;        
    int source;    
} GraphObj;

typedef struct GraphObj* Graph;

/*** Constructors-Destructors ***/

//Function newGraph() returns a Graph pointing to a newly created GraphObj representing a graph having
//n vertices and no edges. 
Graph newGraph(int n){
    Graph G = malloc(sizeof(struct GraphObj));
    G->adj = calloc(n+1, sizeof(List));
    G->color = calloc(n+1, sizeof(int));
    G->parent = calloc(n+1, sizeof(int));
    G->distance = calloc(n+1, sizeof(int));
    G->order = n;
    G->size = 0;
    G->source = NIL;
    for (int i = 1; i <= n; i++) {
        G->adj[i] = newList();
        G->parent[i] = NIL;
        G->distance[i] = INF;
    }
    return G;

}

//Function freeGraph() frees all heap memory associated with the Graph *pG,
//then sets the handle *pG to NULL. 
void freeGraph(Graph* pG){
    if (pG != NULL && *pG != NULL) {
        Graph G = *pG;

        for (int i = 1; i <= G->order; i++) {
            freeList(&G->adj[i]);
        }

        free(G->adj);
        free(G->color);
        free(G->parent);
        free(G->distance);
        free(*pG);

        *pG = NULL;
    }
}


/*** Access functions ***/

int getOrder(Graph G){
    if (G == NULL){
        printf("ERROR:GetOrder() called on NULL reference");
        exit(EXIT_FAILURE);
    }
    return G->order;
}


int getSize(Graph G){
    if (G == NULL){
        printf("ERROR:GetSize() called on NULL reference");
        exit(EXIT_FAILURE);
    }
    return G->size;
}

//getSource() returns the source vertex most recently used in function BFS(), or NIL if
//BFS() has not yet been called.
int getSource(Graph G){
    if (G == NULL){
        printf("ERROR:GetSoruce() called on NULL reference");
        exit(EXIT_FAILURE);
    }
    if (G->source == NIL){
        return NIL;
    }
    return G->source;
}

//Function getParent() will return the parent of vertex u in the BFS tree
//created by BFS(), or NIL if BFS() has not yet been called
int getParent(Graph G, int u){
    if (G == NULL){
        printf("ERROR:GetParent() called on NULL reference");
        exit(EXIT_FAILURE);
    }
    if (u < 1 || u > getOrder(G)){
        printf("ERROR: GetOrder called on Invalid Integer");
        exit(EXIT_FAILURE);
    }
    if (G->source == NIL){
        return NIL;
    }
    return G->parent[u];
}

//Function getDist() returns the distance from
//the most recent BFS source to vertex u, or INF if BFS() has not yet been called.
int getDist(Graph G, int u){
    if (G == NULL){
        printf("ERROR:GetDist() called on NULL reference");
        exit(EXIT_FAILURE);
    }
    if (u < 1 || u > getOrder(G)){
        printf("ERROR: GetDist() called on Invalid Integer");
        exit(EXIT_FAILURE);
    }
    if (G->source == INF){
        return INF;
    }
    return G->distance[u];
}

//Function getPath()
//appends to the List L the vertices of a shortest path in G from source to u, or appends to L the value NIL if
//no such path exists. getPath() has the precondition getSource(G)!=NIL, so BFS() must be called
//before getPath() is called.
void getPath(List L, Graph G, int u){
    if (G == NULL){
            printf("ERROR:GetPath() called on NULL reference");
            exit(EXIT_FAILURE);
    }
    if (u < 1 || u > getOrder(G)){
        printf("ERROR: GetOrder called on Invalid Integer");
        exit(EXIT_FAILURE);
    }
    if(G->source == NIL){
        printf("ERROR: GetPath() called before BFS");
        exit(EXIT_FAILURE);
    }
    if (u == G->source){
        append(L, G->source);
        return;
    }
    if (G->parent[u] == NIL){
        append(L, NIL);
        return;
    }
    getPath(L, G, G->parent[u]);
    append(L, u);

}
//Functions getParent(), getDist() and getPath() all have the
//precondition 1 ≤ 𝑢 ≤ getOrder(𝐺).

/*** Manipulation procedures ***/


/*Function makeNull() deletes all edges of G, restoring it to its 
original (no edge) state. (This is called a null graph in graph theory literature). */
void makeNull(Graph G){
    if (G == NULL){
        printf("Error: calling makeNull() on NULL reference\n");
        exit(EXIT_FAILURE);
    }
    int i;
    for(i = 1; i <= G->order; i++){
        clear(G->adj[i]);
        G->color[i] = WHITE;
        G->distance[i] = INF;
        G->parent[i] = NIL;
    }
    G->size = 0;
    G->source = NIL;
}


/*Function addEdge()
inserts a new edge joining u to v, i.e. u is added to the adjacency List of v, and v to the adjacency List of u.
Your program is required to maintain these lists in sorted order by increasing labels. */
void addEdge(Graph G, int u, int v){
    if (G == NULL) {
        fprintf(stderr, "addEdge() called on NULL reference\n");
        exit(EXIT_FAILURE);
    }
    if (u < 1 || u > getOrder(G)) {
        fprintf(stderr, "addEdge() called with u out of range\n");
        exit(EXIT_FAILURE);
    }
    if (v < 1 || v > getOrder(G)) {
        fprintf(stderr, "addEdge() called with v out of range\n");
        exit(EXIT_FAILURE);
    }
    
    addArc(G, u, v);
    addArc(G, v, u);
    G->size--;
}

/*Both addEdge() and addArc() have the precondition that their two int arguments must lie
in the range 1 to getOrder(G).*/

/*Function addArc()
inserts a new directed edge from u to v, i.e. v is added to the adjacency List of u (but not u to the adjacency
List of v). */
void addArc(Graph G, int u, int v){
    if (G == NULL) {
        fprintf(stderr, "addArc() called on NULL reference\n");
        exit(EXIT_FAILURE);
    }
    if (u < 1 || u > getOrder(G)) {
        fprintf(stderr, "addArc() called with u out of range\n");
        exit(EXIT_FAILURE);
    }
    if (v < 1 || v > getOrder(G)) {
        fprintf(stderr, "addArc() called with v out of range\n");
        exit(EXIT_FAILURE);
    }

    List L = G->adj[u];
    moveFront(L);
    while (index(L) != -1 && v > get(L)) {
        moveNext(L);
    }
    if (index(L) == -1) {
        append(L, v);
    } else {
        insertBefore(L, v);
    }
    G->size++;

}
/*Function BFS() runs the BFS algorithm on the Graph G with source s,
setting the color, distance, parent, and source fields of G accordingly.*/
void BFS(Graph G, int s){
    for (int i = 1; i <= G->order; i++) {
        G->color[i] = WHITE;
        G->distance[i] = INF;
        G->parent[i] = NIL;
    }
    G->source = s;
    G->color[s] = GRAY;
    G->distance[s] = 0;
    G->parent[s] = NIL;
    List Q = newList();
    append(Q, s);
    while(length(Q) != 0) {
        int u = front(Q);
        deleteFront(Q);
        List adj = G->adj[u];
        moveFront(adj);
        while (index(adj) != -1) {
            int v = get(adj);
            if (G->color[v] == WHITE) {
                G->color[v] = GRAY;
                G->distance[v] = G->distance[u] + 1;
                G->parent[v] = u;
                append(Q, v);
            }
            moveNext(adj);
        }
        G->color[u] = BLACK;
    }
    freeList(&Q);
}



/*function printGraph()
prints the adjacency list representation of G to the file pointed to by out. The format of this representation
should match the above examples, so all that is required by the client is a single call to printGraph().*/

/*** Other operations ***/
void printGraph(FILE* out, Graph G){
    if (G == NULL || out == NULL) {
        printf("Error: printGraph called with NULL reference\n");
        exit(EXIT_FAILURE);
    }
    for(int i = 1; i <= G->order; i++) {
        fprintf(out, "%d:", i);
        moveFront(G->adj[i]);
        while(index(G->adj[i]) != -1) {
            fprintf(out, "%d ", get(G->adj[i]));
            moveNext(G->adj[i]);
        }
        fprintf(out, "\n");
    }
}