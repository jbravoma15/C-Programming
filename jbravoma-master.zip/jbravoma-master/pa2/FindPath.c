/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa2                  *
************************/

#include <stdio.h>
#include <stdlib.h>
#include "Graph.h"

#define MAX_LEN 160

int main(int argc, char* argv[]){
// check command line for correct number of arguments
    if(argc != 3){
        printf("Usage: %s <input file> <output file>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // open files for reading and writing
    FILE *in, *out;
    in = fopen(argv[1], "r");
    if(in == NULL){
        printf("Unable to open file %s for reading\n", argv[1]);
        exit(EXIT_FAILURE);
    }
    out = fopen(argv[2], "w");
    if(out == NULL){
        printf("Unable to open file %s for writing\n", argv[2]);
        exit(EXIT_FAILURE);
    }

    // take the integers given in the file and begin to create the graph using List.c and Graph.c

    int n, u, v;        
    fscanf(in, "%d", &n);
    Graph G = newGraph(n);

    while(fscanf(in, "%d %d", &u, &v) == 2){
        if(u == 0 && v == 0){
            break;
        }
        addEdge(G, u, v);
    }

    printGraph(out, G);
    fprintf(out, "\n");

    // Check the pair in the grpah and determine the shortest path(s)
    while(fscanf(in, "%d %d", &u, &v) == 2){
        if(u == 0 && v == 0){
            break;
        }
        List L = newList();
        BFS(G, u);
        getPath(L, G, v);

        fprintf(out, "\nThe distance from %d to %d is ", u, v);
        if(getDist(G, v) == INF){
            fprintf(out, "infinity\n");
            fprintf(out,"No %d-%d path exists", u, v);
        }
        else{
            fprintf(out, "%d\n", getDist(G, v));
        }

        if(front(L) == NIL){
            printf("No %d-%d path exsits \n", u, v);
        }
        else{
            fprintf(out, "A shortest %d-%d path is: ", u, v);
            printList(out, L);
            fprintf(out, "\n");
        }
        

        freeList(&L);
    }

    // free graph memory and close files
    freeGraph(&G);
    fclose(in);
    fclose(out);

    return 0;
}
