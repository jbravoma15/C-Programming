/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa2                  *
************************/

#include "List.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>



typedef struct NodeObj{ //Created a pointer that points to the next node in the linked list
    int data;
    struct NodeObj* next;
    struct NodeObj* prev;
}NodeObj;

typedef NodeObj* Node;


typedef struct ListObj{
    Node front;
    Node back;
    Node pointer;
    int Index; 
    int length;
}ListObj;

void FreeNode(Node* pN){
    if (pN != NULL && *pN != NULL) { // make sure the pointer is not null and the node exists
        free(*pN); // free the memory allocated for the node
        *pN = NULL; // set the pointer to null to avoid dangling pointers
    }
}

Node NewNode(int data){ //Initailize the pointer to NewNode
    Node N = (Node) malloc(sizeof(NodeObj));
    N->data = data;
    N->next = NULL;
    N->prev = NULL;
    return(N);
}


// Constructors-Destructors ---------------------------------------------------
List newList(void){ // Creates and returns a new empty List.
    List L;
    L = malloc(sizeof(ListObj));                    /// prev was LIST
    L->front =NULL;
    L->back = NULL;
    L->pointer = NULL;
    L->length = 0;
    L->Index = -1;
    return(L);
}

void freeList(List* pL) {
    if (pL != NULL && *pL != NULL) {        // make sure the pointer is not null and the list exists
        while ((*pL)->front != NULL) {         // iterate through all nodes in the list
            Node temp = (*pL)->front;          // temporarily store the front node
            (*pL)->front = (*pL)->front->next; // move the front pointer to the next node
            free(temp);                        // free the memory allocated for the node
        }
        free(*pL);                             // free the memory allocated for the list struct
        *pL = NULL;                            // set the pointer to null to avoid dangling pointers
    }
}

// Access functions -----------------------------------------------------------
int length(List L){// Returns the number of elements in L.
    return L-> length;
} 
int index(List L){// Returns index of cursor element if defined, -1 otherwise.
    if (L != NULL){
        return L->Index;
    }
    printf("Error: Index called on NULL Reference \n");
    exit(EXIT_FAILURE);
}
int front(List L){
    if (L->length > 0) {
        return L->front->data;
    }else{
        printf("Error: front called on empty list\n");
        exit(1); 
    }
} // Returns front element of L. Pre: length()>0

int back(List L){
    if (L->length > 0) {
        return L->back->data;
    }else{
        printf("Error: back called on empty list \n");
        exit(1);
    }
} // Returns back element of L. Pre: length()>0

int get(List L){
    if (length(L) < 0 ) {
        printf("Error: get called on empty list \n");
        exit(EXIT_FAILURE);
    }
    if(index(L) < 0){
        printf("Error: get called on undefined list \n");
        exit(EXIT_FAILURE);
    }
    return L->pointer->data;
    
} // Returns cursor element of L. Pre: length()>0, index()>=0

bool equals(List A, List B){
    if( A == NULL || B == NULL){
        printf("Error: equals called on NULL Reference \n");
        exit(EXIT_FAILURE);
    }
    if (A->length != B->length) {
        return false;
    }
    Node nodeA = A->front;
    Node nodeB = B->front;
    while (nodeA != NULL && nodeB != NULL) {
        if (nodeA->data != nodeB->data) {
            return false;
        }
        nodeA = nodeA->next;
        nodeB = nodeB->next;
    }
    return true;
} // Returns true iff Lists A and B are in same
 // state, and returns false otherwise.


// Manipulation procedures ----------------------------------------------------
void clear(List L){
    NodeObj* Node = L->front;
    while (Node != NULL) {              // While the node is Null, we need to free the node 
        NodeObj* next = Node->next;
        free(Node);
        Node = next;
    }
    L->length = 0;
    L->Index = -1;
    L->front = L->back = NULL;
    L->pointer = NULL;
} // Resets L to its original empty state.


void set(List L, int x){
    Node SetNode = NewNode(x);
    if (L->length < 0){
        printf("Error: Set() called on an empty List");
        exit(EXIT_FAILURE);
    }
    if (L->Index < 0){
        printf("Error: pointer is undefined");
        exit(EXIT_FAILURE);
    }
    L->pointer = SetNode;
} // Overwrites the cursor element’s data with x.
 // Pre: length()>0, index()>=0


void moveFront(List L){
    if( L==NULL ){
      printf("List Error: calling moveFront() on NULL reference\n");
      exit(EXIT_FAILURE);
    }
    if (length(L) > 0){  // if list is not empty or not null
        L->pointer = L->front;
        L->Index = 0;        // set pointer to front 
    }
    return;
} // If L is non-empty, sets cursor under the front element,
 // otherwise does nothing.


void moveBack(List L){
    if( L == NULL ){
      printf("List Error: calling moveBack() on NULL reference\n");
      exit(EXIT_FAILURE);
    }
    if (L->length > 0){  // if list is not empty or not null
        L->pointer = L->back;       
        L->Index = L->length - 1;       // set pointer to BACK 
    } 
    return;
} // If L is non-empty, sets cursor under the back element,
 // otherwise does nothing.


void movePrev(List L){
    if( L == NULL ){
      printf("List Error: calling movePrev() on NULL reference\n");
      exit(EXIT_FAILURE);
    }
    if (L->pointer != NULL && L->pointer == L->front){// if cursor is not empty or not null
        L->pointer = NULL;
        L->Index = -1;   
    }
    if(L->pointer != NULL && L->pointer != L->front){ 
        L->pointer = L->pointer->prev;
        L->Index--;
    }

} // If cursor is defined and not at front, move cursor one
 // step toward the front of L; if cursor is defined and at
 // front, cursor becomes undefined; if cursor is undefined
 // do nothing


void moveNext(List L){
    if (L->pointer != NULL && L->pointer == L->back){// if cursor is not empty or not null
        L->pointer = NULL;
        L->Index= -1;
            
    }
    if(L->pointer != NULL && L->pointer != L->back){ 
        L->pointer = L->pointer->next;
        L->Index ++;
    }

} // If cursor is defined and not at back, move cursor one
 // step toward the back of L; if cursor is defined and at
 // back, cursor becomes undefined; if cursor is undefined
 // do nothing


void prepend(List L, int x){
    Node newNode = NewNode(x);   
    if (L->length == 0) {
        L->front = L->back = newNode;
    } else {
        newNode->next = L->front;   // Set New notd to front 
        L->front->prev = newNode;
        L->front = newNode;
        if(L->pointer != NULL){
             L->Index++;
        }
       
    }
    L->length++;
    

} // Insert new element into L. If L is non-empty,
 // insertion takes place before front element.


void append(List L, int x){
    Node new_Node = NewNode(x);
    if (L->length == 0) {
        L->front = new_Node;
        L->Index++;
    } else {
        new_Node->prev = L->back;
        L->back->next = new_Node;
    }
    L->back = new_Node;
    L->length++;

} // Insert new element into L. If L is non-empty,
 // insertion takes place after back element.


void insertBefore(List L, int x){

    if (length(L) < 0) {
        printf("Error: InsertAfter() called on an empty List.\n");
        exit(EXIT_FAILURE);
    }
    if (L->Index < 0 ) {
        printf("Error: Index is undefined.\n");
        exit(EXIT_FAILURE);
    }
    Node newNode = NewNode(x);
     if(L->pointer == L->front){
      newNode->next = L->front;
      L->front->prev = newNode;
      L->front = newNode;
   }else{
      newNode->prev = L->pointer->prev;
      newNode->next = L->pointer;
      L->pointer->prev->next = newNode;
      L->pointer->prev = newNode;
   }
    L->Index++;
    L->length++;
} // Insert new element before cursor.
 // Pre: length()>0, index()>=0


void insertAfter(List L, int x){
    if (length(L) < 0) {
        printf("Error: InsertAfter() called on an empty List.\n");
        exit(EXIT_FAILURE);
    }
    if (L->Index < 0 ) {
        printf("Error: Index is undefined.\n");
        exit(EXIT_FAILURE);
    }

    Node newNode = NewNode(x);
    if (L->pointer == L->back) {
        //Cursor is at the back of the list
        newNode->prev = L->back;
        L->back->next = newNode;
        L->back = newNode;
    } else{
        // Cursor is not at the back of the list
        newNode->next = L->pointer->next;
        newNode->prev = L->pointer;
        L->pointer->next->prev = newNode;
        L->pointer->next = newNode;
    }
    L->length++; // Increment the length of the list 

} // Insert new element after cursor.
 // Pre: length()>0, index()>=0


void deleteFront(List L){               //FIX
    if (length(L) <= 0) {
        printf("Error: DeleteFront() called on an empty List.\n");
        exit(EXIT_FAILURE);
    }
    Node FrontNode = L->front;
    if (length(L) == 1) {
        FreeNode(&L->front);
        L->front = NULL;
        L->back = NULL;
        L->pointer = NULL;
        L->Index = -1;
        L->length = 0;
    } else {
        L->front = L->front->next;
        L->front->prev = NULL;
        FreeNode(&FrontNode);
        if (L->Index == 0) {
            L->pointer = NULL;
        } else if (L->Index == 1) {
            L->pointer = L->front;
        }
        L->Index--;
        L->length--;
    }


    
}
    

 // Delete the front element. Pre: length()>0


void deleteBack(List L){
    if (length(L) <= 0) {
        printf("Error: DeleteBack() called on an empty List.\n");
        exit(EXIT_FAILURE);
    }
    Node BackNode = L->back;
    if (length(L) == 1) {
        FreeNode(&L->front);
        L->front = NULL;
        L->back = NULL;
        L->pointer = NULL;
        L->Index = -1;
        L->length = 0;
    } else {
        if (L->pointer == BackNode) {
            L->pointer = NULL;
            L->Index = -1;
        }
        L->back = L->back->prev;
        L->back->next = NULL;
        FreeNode(&BackNode);
        L->length--;
    }
    }
 // Delete the back element. Pre: length()>0


void delete(List L){
    if (length(L) < 0){
        printf("Error: Delete() called on an empty List");
        exit(EXIT_FAILURE);
    }
    if (L->Index < 0){
        printf("Error: pointer is undefined");
        exit(EXIT_FAILURE);
    }
    if (L->pointer->prev != NULL) {
        L->pointer->prev->next = L->pointer->next;
    } else {
        L->front = L->pointer->next;
    }
    if (L->pointer->next != NULL) {
        L->pointer->next->prev = L->pointer->prev;
    } else {
        L->back = L->pointer->prev;
    }
    FreeNode(&L->pointer);
    L->pointer = NULL;
    L->length--;
    L->Index = -1;
    
    }// Delete cursor element, making cursor undefined.
 // Pre: length()>0, index()>=0


// Other operations -----------------------------------------------------------
void printList(FILE* out, List L){
    Node N = NULL;
    if (out == NULL || L == NULL) { // Check for invalid input parameters
        printf("Error: Printlist called on NULL List");
        exit(1);
    }
    for (N = L-> front; N != NULL;N = N->next) { // Iterate over the list
        fprintf(out, "%d", N ->data); // Print the current element
        if (L->Index < L->length - 1) { // Add a space separator if needed
            fprintf(out, " ");
        }
    }
    fprintf(out, " ");

} // Prints to the file pointed to by out, a
 // string representation of L consisting
 // of a space separated sequence of integers,
// with front on left.
List copyList(List L){

    if(L==NULL){
        printf("Error: pointer is undefined");
        exit(EXIT_FAILURE);
    }
    List copy = newList();
    Node N = L->front;
    while (N != NULL) {
        append(copy, N->data);
        N = N->next;
    }
    return copy;

} // Returns a new List representing the same integer
 // sequence as L. The cursor in the new list is undefined,
// regardless of the state of the cursor in L. The state
// of L is unchanged
