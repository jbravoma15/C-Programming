/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa6                  *
************************/

#include<iostream>
#include<string>
#include<stdexcept>
#include"BigInteger.h"
#include"List.h"

using namespace std;

int main(){


    //Testing BigInteger
    cout << endl;
    cout << "Testing BigInt N" << endl;
    //BigInteger N;
    BigInteger A;
    BigInteger B;
    BigInteger C;
    BigInteger D;
    BigInteger E;
    BigInteger F;

    //Testing BigInteger String
    cout << endl;
    cout << "Testing BigInt toString" << endl;
    A = BigInteger("+111122223333");
    B = BigInteger("+222211110000");
    C = BigInteger("+333322221111");
    D = BigInteger("+444444444444");
    E = BigInteger("-44444444444");
    F = BigInteger();


    cout << endl;
    cout << "A = " << A << endl;
    cout << "B = " << B << endl;
    cout << "C = " << C << endl;
    cout << "D = " << D << endl;
    cout << "E = " << E << endl;
    cout << "F = " << F << endl;
    cout << endl;


    //Testing Sign
    cout << endl;
    cout << "Testing BigInt Sign" << endl;
    cout << endl;
    cout << "A.Sign() = " << A.sign() << endl;
    cout << "B.Sign() = " << B.sign() << endl;
    cout << "C.Sign() = " << C.sign() << endl;
    cout << "D.Sign() = " << D.sign() << endl;
    cout << "E.Sign() = " << E.sign() << endl;
    cout << "F.Sign() = " << F.sign() << endl;
    cout << endl;

    //testing compare
    cout << endl;
    cout << "Testing BigInt Compare" << endl;
    B = A;
    cout << endl;
    cout << "A.compare(B) (Less than) = " << A.compare(B) << endl;
    cout << "C.compare(D) (equal) = " << C.compare(D) << endl;
    cout << "F.compare(F) (Greater than)= " << F.compare(E) << endl;
    cout << endl;

    //testing MakeZero
    cout << endl;
    cout << "Testing BigInt MakeZero" << endl;
    A.makeZero();
    B.makeZero();
    cout << endl;
    cout << "A = " << A << endl;
    cout << "B = " << B << endl;
    cout << endl;


    //Testing negate
    cout << endl;
    cout << "Testing BigInt Negate" << endl;
    
    A = BigInteger("+111122223333");
    B = BigInteger("+222211110000");
    C = BigInteger("-333322221111");
    A.negate();
    B.negate();
    C.negate();
    cout << endl;
    cout << "A = " << A << endl;
    cout << "B = " << B << endl;
    cout << "C = " << C << endl;
    cout << endl;

    //Testing Add
    cout << endl;
    cout << "Testing BigInt Add" << endl;
    A = BigInteger("+111122223333");
    B = BigInteger("+222211110000");
    C = BigInteger("-333322221111");
    D = A+B;
    cout << endl;
    cout << "A = " << A << endl;
    cout << "B = " << B << endl;
    cout << "A+B = " << D << endl;
    
    F = BigInteger("-333333333333");
    E = D+F;
    cout << "F = " << F << endl;
    cout << "D = " << D << endl;
    cout << "D+F = " << E << endl;

    E = BigInteger("+222211110000");
    F = BigInteger("-333333333333");
    D = E+F;
    cout << "F = " << F << endl;
    cout << "E = " << E << endl;
    cout << "E+F = " << D << endl;

    D = D+C;
    cout << "C = " << C << endl;
    cout << "D+C = " << D << endl;

    //Testing Sub
    cout << endl;
    cout << "Testing BigInt Sub" << endl;
    A = BigInteger("+111122223333");
    B = BigInteger("+222211110000");
    C = BigInteger("-333322221111");
    D = B-A;
    cout << endl;
    cout << "A = " << A << endl;
    cout << "B = " << B << endl;
    cout << "B-A = " << D << endl;
    F = BigInteger("-333333333333");
    E = D-F;
    cout << "F = " << F << endl;
    cout << "D = " << D << endl;
    cout << "D-F = " << E << endl;



    //Testing Mult
    cout << endl;
    cout << "Testing BigInt Mult" << endl;
    A = BigInteger("+111122223333");
    B = BigInteger("+222211110000");
    C = BigInteger("-333322221111");
    D = A*B;
    cout << endl;
    cout << "A = " << A << endl;
    cout << "B = " << B << endl;
    cout << "A*B = " << D << endl;
    E = D*C;
    cout << "C = " << C << endl;
    cout << "D*C = " << E << endl;
    D = D*C;




    return EXIT_SUCCESS;
}
