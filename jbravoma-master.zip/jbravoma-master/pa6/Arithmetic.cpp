/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa6                  *
************************/
#include <iostream>
#include <fstream>
#include <string>
#include "BigInteger.h"

using namespace std;

int main(int argc, char* argv[]){
	if (argc < 3) {
        cout << "Usage: Arithmetic <input file> <output file>" << endl;
        return 1;
    }
	
    std::string inputFile = argv[1];
    std::string outputFile = argv[2];

    std::ifstream inFile(inputFile);
    if (!inFile) {
        std::cout << "Error opening input file: " << inputFile << std::endl;
        return 1;
    }
	std::ofstream outFile(outputFile);
    if (!outFile) {
        std::cout << "Error opening output file: " << outputFile << std::endl;
        return 1;
    }

    std::string line1, line2, line3;
    getline(inFile, line1);
    getline(inFile, line2);
    getline(inFile, line3);
    inFile.close();

    BigInteger A(line1);
    BigInteger B(line3);

    BigInteger AplusB = A+B;
    BigInteger AminusB = A-B;
    BigInteger AminusA = A-A;
    BigInteger threeAminusTwoB = 3*A - 2*B;
    BigInteger AB = A*B;
    BigInteger ASquared = A*A;
    BigInteger BSquared = B*B;
    BigInteger nineAto4Plus16Bto5 = 9*(A*A*A*A) + 16*(B*B*B*B*B);

	outFile << A << endl;
	outFile << endl;
	outFile << B << endl;
	outFile << endl;
    outFile << AplusB << endl;
	outFile << endl;
    outFile << AminusB << endl;
	outFile << endl;
    outFile << AminusA << endl;
	outFile << endl;
    outFile << threeAminusTwoB << endl;
	outFile << endl;
    outFile << AB << endl;
	outFile << endl;
    outFile << ASquared << endl;
	outFile << endl;
    outFile << BSquared << endl;
	outFile << endl;
    outFile << nineAto4Plus16Bto5 << endl;


    outFile.close();

    return 0;

}