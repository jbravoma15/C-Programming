/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa6                  *
************************/
#include <vector>
#include <algorithm>
#include <set>
#include <stdexcept>
#include "List.h"

using namespace std;

// Node constructor
List::Node::Node(ListElement x) {
    data = x;
    next = nullptr;
    prev = nullptr;
}


// Class Constructors & Destructors ----------------------------------------

// Creates new List in the empty state.
List::List() {
    frontDummy = new Node(-1);
    backDummy = new Node(-2);
    frontDummy->next = backDummy;
    backDummy->prev = frontDummy;
    beforeCursor = frontDummy;
    afterCursor = backDummy;
    pos_cursor = 0;
    num_elements = 0;

}



List::List(const List& L) {
    frontDummy = new Node(-1);
    backDummy = new Node(-2);
    frontDummy->next = backDummy;
    backDummy->prev = frontDummy;
    beforeCursor = frontDummy;
    afterCursor = backDummy;
    pos_cursor = 0;
    num_elements = 0;
    

    // Copy the elements from L to this List
    Node* L_node = L.frontDummy->next;
    while (L_node->next != nullptr) {
        this->insertBefore(L_node->data);
        L_node = L_node->next;
    }
    moveFront();
}

// Destructor
List::~List() {
    clear();
    delete frontDummy;//check
    delete backDummy;
}


// Access functions --------------------------------------------------------

// length()
// Returns the length of this List.
int List::length() const {
    return num_elements;
}

// front()
// Returns the front element in this List.
// pre: length()>0
ListElement List::front() const {
    if (length() <= 0) {
        throw std::length_error("List: front(): empty list");
    }
    return frontDummy->next->data;
}


// back()
// Returns the back element in this List.
// pre: length()>0
ListElement List::back() const{
    if (length() <= 0) {
        throw std::length_error("List: back(): empty list");
    }
    return backDummy->prev->data;

}

// position()
// Returns the position of cursor in this List: 0 <= position() <= length().
int List::position() const{
    return pos_cursor;
}

// peekNext()
// Returns the element after the cursor.
// pre: position()<length()
ListElement List::peekNext() const{
    if (pos_cursor >= num_elements) {
        throw std::range_error("List: peekNext(): cursor at back");
        }
    return afterCursor->data;
}

// peekPrev()
// Returns the element before the cursor.
// pre: position()>0
ListElement List::peekPrev() const{
    if (pos_cursor <= 0) {
        throw std::range_error("List: peekPrev(): cursor at front");
        }
    return beforeCursor->data;
}


// Manipulation procedures -------------------------------------------------

// clear()
// Deletes all elements in this List, setting it to the empty state.
void List::clear(){
    moveFront();
    while(length() > 0){
        eraseAfter();
    }
    frontDummy->next = backDummy;
    backDummy->prev = frontDummy;
    beforeCursor = frontDummy;
    afterCursor = backDummy;
    pos_cursor = 0;
    num_elements = 0;
}

// moveFront()
// Moves cursor to position 0 in this List.
void List::moveFront(){
    beforeCursor = frontDummy;
    afterCursor = frontDummy->next;
    pos_cursor = 0;
}

// moveBack()
// Moves cursor to position length() in this List.
void List::moveBack(){
    beforeCursor = backDummy->prev;
    afterCursor = backDummy;
    pos_cursor = num_elements;
}

// moveNext()
// Advances cursor to next higher position. Returns the List element that
// was passed over. 
// pre: position()<length() 
ListElement List::moveNext(){
    if (position() >= num_elements) {
        throw std::range_error("List: moveNext(): cursor at back");
        }
    beforeCursor = afterCursor;
    afterCursor = afterCursor->next;
    pos_cursor++;
    return beforeCursor->data;

}

// movePrev()
// Advances cursor to next lower position. Returns the List element that
// was passed over. 
// pre: position()>0
ListElement List::movePrev(){
    if (position() <= 0) {
        throw std::range_error("List: movePrev(): cursor at front");
    }
    afterCursor = beforeCursor;
    beforeCursor = beforeCursor->prev;
    pos_cursor--;
    return afterCursor->data;

}

// insertAfter()
// Inserts x after cursor.
void List::insertAfter(ListElement x){
    Node* newNode = new Node(x);
    newNode->next = afterCursor;
    newNode->prev = beforeCursor;
    afterCursor->prev = newNode;
    beforeCursor->next = newNode;
    afterCursor = newNode;
    num_elements++;

}

// insertBefore()
// Inserts x before cursor.
void List::insertBefore(ListElement x){
    Node* newNode = new List::Node(x);
    newNode->next = afterCursor;
    newNode->prev = beforeCursor;
    afterCursor->prev = newNode;
    beforeCursor->next = newNode;
    beforeCursor = newNode;
    num_elements++;
    pos_cursor++;

}

// setAfter()
// Overwrites the List element after the cursor with x.
// pre: position()<length()
void List::setAfter(ListElement x){
     if (pos_cursor >= num_elements) {
        throw std::range_error("List: setAfter(): cursor at back");
        }
    afterCursor->data = x;

}

// setBefore()
// Overwrites the List element before the cursor with x.
// pre: position()>0
void List::setBefore(ListElement x){
    if (pos_cursor == 0) {
        throw std::range_error("List: setBefore(): cursor at front");
        }
    beforeCursor->data = x;
}

// eraseAfter()
// Deletes element after cursor.
// pre: position()<length()
void List::eraseAfter(){
    if (position() >= length()) {
        throw std::range_error("List: eraseAfter(): cursor at back");
    }
    beforeCursor->next = afterCursor->next;
    afterCursor->next->prev = beforeCursor;
    Node *temp = afterCursor;
    delete(temp);
    afterCursor = beforeCursor->next;
    num_elements--;

}

// eraseBefore()
// Deletes element before cursor.
// pre: position()>0
void List::eraseBefore(){
    if (pos_cursor == 0) {
        throw std::range_error("List: eraseBefore(): cursor at front");
    }
    afterCursor->prev = beforeCursor->prev;
    beforeCursor->prev->next = afterCursor;
    Node *temp = beforeCursor;
    delete(temp);
    beforeCursor = afterCursor->prev;
    pos_cursor--;
    num_elements--;
    
}


// Other Functions ---------------------------------------------------------

// findNext()
// Starting from the current cursor position, performs a linear search (in 
// the direction front-to-back) for the first occurrence of element x. If x
// is found, places the cursor immediately after the found element, then 
// returns the final cursor position. If x is not found, places the cursor 
// at position length(), and returns -1. 
int List::findNext(ListElement x){
    Node* current = afterCursor;
    int index = pos_cursor + 1;
    while (current != backDummy) {
        if (current->data == x) {
            beforeCursor = current;
            afterCursor = current->next;
            pos_cursor = index;
            return index;
        }
        current = current->next;
        index++;
    }

    moveBack(); 
    return -1;

}

// findPrev()
// Starting from the current cursor position, performs a linear search (in 
// the direction back-to-front) for the first occurrence of element x. If x
// is found, places the cursor immediately before the found element, then
// returns the final cursor position. If x is not found, places the cursor 
// at position 0, and returns -1. 
int List::findPrev(ListElement x){
    Node* current = beforeCursor;
    int index = pos_cursor - 1;
    while (current != frontDummy && current->data != x) {
        current = current->prev;
        index--;
    }
    if (current == frontDummy) {
        moveFront(); 
        return -1;
    }
    afterCursor = current;
    beforeCursor = current->prev;
    pos_cursor = index;
    return index;

}

// cleanup()
// Removes any repeated elements in this List, leaving only unique elements.
// The order of the remaining elements is obtained by retaining the frontmost 
// occurrance of each element, and removing all other occurances. The cursor 
// is not moved with respect to the retained elements, i.e. it lies between 
// the same two retained elements that it did before cleanup() was called.
// Complete using 3 while nodes 
// 2 nodes 
void List::cleanup(){
    Node* before = beforeCursor;
    Node* after = afterCursor;
    moveFront();
    if (length() == 0) {
        moveNext();
    }
    while (afterCursor != backDummy) {
        if (pos_cursor < num_elements) {
            int check = beforeCursor->data;
            int pos = position();
            while (findNext(check) != -1) {
                if (beforeCursor == before) {
                    before = before->prev;
                }
                else if (beforeCursor == after) {
                    after = after->next;
                }
                eraseBefore();
            }
            moveFront();
            while (pos_cursor != pos && pos_cursor != length()) {
                moveNext();
            }
            if (pos_cursor != length()) {
                moveNext();
            }
        }else{
            moveBack();
        }
    }
    moveFront();
    for (; beforeCursor != before; moveNext()) {
        continue;
    }
    

}

// concat()
// Returns a new List consisting of the elements of this List, followed by
// the elements of L. The cursor in the returned List will be at postion 0.
List List::concat(const List& L) const{
    List newList;
    Node* current = frontDummy->next;
    while (current != backDummy) {
        newList.insertBefore(current->data);
        current = current->next;
    }
    Node* L_node = L.frontDummy->next;
    while (L_node != L.backDummy) {
        newList.insertBefore(L_node->data);
        L_node = L_node->next;
    }
    newList.moveFront();
    return newList;
}

// to_string()
// Returns a string representation of this List consisting of a comma 
// separated sequence of elements, surrounded by parentheses.
std::string List::to_string() const{
    std::string result = "(";
    Node* current = frontDummy->next;
    while (current != backDummy) {
        result += std::to_string(current->data);
        if (current->next != backDummy) {
            result += ", ";
        }
        current = current->next;
    }
    result += ")";
    return result;
}

// equals()
// Returns true if and only if this List is the same integer sequence as R.
// The cursors in this List and in R are unchanged.
bool List::equals(const List& R) const{
    if (num_elements != R.num_elements) {
        return false;
    }

    // Compare each element of the lists
    Node* currentThis = frontDummy->next;
    Node* currentR = R.frontDummy->next;

    while (currentThis != backDummy && currentR != R.backDummy) {
        if (currentThis->data != currentR->data) {
            return false;
        }
        currentThis = currentThis->next;
        currentR = currentR->next;
    }

    // If all elements are equal and the end of both lists is reached, return true
    return (currentThis == backDummy && currentR == R.backDummy);
}


// Overriden Operators -----------------------------------------------------

// operator<<()
// Inserts string representation of L into stream.
std::ostream& operator<<( std::ostream& stream, const List& L ){
    stream << L.to_string();
    return stream;
}

// operator==()
// Returns true if and only if A is the same integer sequence as B. The 
// cursors in both Lists are unchanged.
bool operator==( const List& A, const List& B ){
    return A.equals(B);
}

// operator=()
// Overwrites the state of this List with state of L.
List& List::operator=( const List& L ){
    if( this != &L ){ 
      List temp = L;

      std::swap(frontDummy, temp.frontDummy);
      std::swap(backDummy, temp.backDummy);
      std::swap(num_elements, temp.num_elements);
      std::swap(pos_cursor,temp.pos_cursor);
      std::swap(beforeCursor, temp.beforeCursor);
      std::swap(afterCursor,temp.afterCursor);
   }

    return *this;
}
