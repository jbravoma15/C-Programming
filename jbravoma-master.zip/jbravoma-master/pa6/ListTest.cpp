/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa6                  *
************************/

#include<iostream>
#include<stdexcept>
#include"List.h"

using namespace std;

int main(){
    List A;
    List B;

    for(int i = 1; i <= 10; i++){
        A.insertBefore(i);
    }
    cout << "A = " << A << endl;

    for(int i = 1; i <= 11; i++){
        B.insertBefore(i);
    }
    cout << endl;

    cout << "B = " << B << endl;
    cout << endl;

    cout<< "List of A compents: ";
    cout << "A = " << A << endl;
    cout << "Length = " << A.length() << endl;
    cout << "Cursor = " << A.position() << endl;
    cout << "Front = " << A.front() << endl;
    cout << "Back = " << A.back() << endl;
    cout << "Pos = " << A.position() << endl;
    cout << endl;

    cout<< "List of B compents: ";
    cout << "B = " << B << endl;
    cout << "Length = " << B.length() << endl;
    cout << "Cursor = " << B.position() << endl;
    cout << "Front = " << B.front() << endl;
    cout << "Back = " << B.back() << endl;
    cout << "Pos = " << B.position() << endl;
    cout << endl;

    //Testing To String
    std::string listString = B.to_string();

    // Output the resulting string
    std::cout << "List B using to_string: " << listString << std::endl;
    cout << endl;

    //testing Equals 
    cout << "Testing Equals: " << endl;
    if (A == B) {
        cout << "A and B are equal." << endl;
    } else {
        cout << "A and B are not equal." << endl;
    }
    cout << endl;

    //testing concat

    cout << "Testing Concat: " << endl;
    List C = A.concat(B);
    cout << "C = " << C << endl;
    cout << endl;

    //testing cleanup
    cout << "Testing Cleanup: " << endl;
    C.cleanup();
    cout << "C (after cleanup) = " << C << endl;
    cout << endl;


    //testing FindNext
    cout << "Testing FindNext: " << endl;
    int pos1 = C.findNext(5);
    if (pos1 != -1) {
        cout << "5 found at position " << pos1 << endl;
    } else {
        cout << "5 not found." << endl;
    }
    cout << endl;


    //testing FindPrev 
    cout << "Testing FindPrev: " << endl;
    int pos2 = A.findPrev(8);
    if (pos2 != -1) {
        cout << "8 found at position " << pos2 << endl;
    } else {
        cout << "8 not found." << endl;
    }
    cout << endl;


    //testing SetAfter
    cout << "Testing SetAfter: " << endl;
    try {
        C.setAfter(100);
        cout << "After setting data after cursor: C = " << C << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;

    //Testing SetBefore
    try {
        C.setBefore(200);
        cout << "After setting data before cursor: C = " << C << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;


    //Testing Clear
    cout << "Testing Clear: " << endl;
    C.clear();
    cout << "C (after clear) = " << C << endl;
    cout << endl;


    //testing eraseBefore
    cout << "Testing EraseBefore: " << endl;
    try {
        C.eraseBefore();
        cout << "After erasing before cursor: C = " << C << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;

    cout << "Testing EraseBefore: " << endl;
    try {
        A.eraseBefore();
        cout << "After erasing before cursor: A = " << A << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;



    //testing ereaseAfter 
    cout << "Testing EraseAfter: " << endl;
    try {
        C.eraseAfter();
        cout << "After erasing after cursor: C = " << C << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;

    cout << "Testing EraseAfter: " << endl;
    try {
        A.eraseAfter();
        cout << "After erasing after cursor: A = " << A << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;


    //testing MoveNext
    cout << "Testing MoveNext: " << endl;
    try {
        C.moveNext();
        cout << "After moving cursor next: C = " << C << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;

    cout << "Testing MoveNext: " << endl;
    try {
        cout << "Cursor = " << A.position() << endl; 
        A.moveNext();
        cout << "After moving cursor next: A = " << A.position() << endl;
    } catch (const std::range_error& e) {
        cout << "Error: " << e.what() << endl;
    }
    cout << endl;



    //Testing MovePrev
    cout << "Testing MovePrev: " << endl;
    try {
      C.movePrev();
      cout << "After moving cursor prev: C = " << C << endl;
    } catch (const std::range_error& e) {
      cout << "Error: " << e.what() << endl;
    }
    cout << endl;

    cout << "Testing MovePrev: " << endl;
    try {
      cout << "Cursor = " << A.position() << endl;
      A.movePrev();
      cout << "After moving cursor prev: A = " << A.position() << endl;
    } catch (const std::range_error& e) {
      cout << "Error: " << e.what() << endl;
    }
    cout << endl;

    //testing insertAfter
    cout << "Testing insertAfter: " << endl;
    try {
        C.insertAfter(5);
        cout << "After inserting after C: C = " << C << endl;
        } catch (const std::range_error& e) {
            cout << "Error: " << e.what() << endl;
            }
    cout << endl;

    //testing insertBefore
    cout << "Testing insertBefore: " << endl;
    try {
        C.insertBefore(5);
        cout << "After inserting before C: " << C << endl;
        } catch (const std::range_error& e) {
            cout << "Error: " << e.what() << endl;
            }
    cout << endl;

    //Testing MoveFront
    cout << "Testing MoveFront: " << endl;
    try {
        A.moveFront();
        cout << "After moving cursor front:  " << A.position() << endl;
        } catch (const std::range_error& e) {
            cout << "Error: " << e.what() << endl;
            }
    cout << endl;

    //Testing MoveBack
    cout << "Testing MoveBack: " << endl;

    try {
        B.moveBack();
        cout << "After moving cursor back: " << B.position() << endl;
        } catch (const std::range_error& e) {
            cout << "Error: " << e.what() << endl;
            }
    cout << endl;
   
   return( EXIT_SUCCESS );
}


