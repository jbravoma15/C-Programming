/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa6                  *
************************/
#include<iostream>
#include<sstream>
#include<string>
#include<iomanip>
#include "BigInteger.h"


const ListElement base  = 1000000000;
const int         power = 9;    

using namespace std;

//Helper Functions

// negateList()
// Changes the sign of each integer in List L. Used by sub().
void negateList(List& L){
    L.moveFront();
    while (L.position() < L.length()) {
        ListElement x = L.moveNext();
        if (x == 0)
            continue;
        L.eraseBefore();
        L.insertBefore(-x);
    }

}


// sumList()
// Overwrites the state of S with A + sgn*B (considered as vectors).
// Used by both sum() and sub().
void sumList(List& S, List A, List B, int sgn){
    
    // Move to the back of A and B
    A.moveBack();
    B.moveBack();

    //Clear the state of "S"
    S.clear();

    // Move to the back of s
    S.moveBack();

    // Iterate through the lists A and B
    while (A.position() > 0 && B.position() > 0) {
        ListElement x = A.movePrev();
        ListElement y = B.movePrev();
        S.insertAfter(x + (y * sgn));
    }

    // Iterate through list A
    while (A.position() > 0) {
        ListElement x = A.movePrev();
        S.insertAfter(x);
    }

    // Iterate through list B
    while (B.position() > 0) {
        ListElement y = B.movePrev();
        S.insertAfter(y * sgn);
    }
}



// normalizeList()
// Performs carries from right to left (least to most significant
// digits), then returns the sign of the resulting integer. Used
// by add(), sub() and mult().
int normalizeList(List& L){
    int carry = 0;
    int sign = 1;
    ListElement set;
    ListElement num = 0;

    if (L.front() < 0) {
        negateList(L);
        sign = -1;
    }

    L.moveBack();
    while (L.position() > 1) {
        L.movePrev();
        num = L.peekNext();
        set = L.peekPrev();

        if (num > 0) {
            carry = num / base;
            L.setAfter(num % base);
            L.setBefore(set + carry);
        } else if (num < 0) {
            int numBas = (num / base) - 1;
            carry = (numBas) * -1;
            L.setAfter(((num + (carry * base)) % base));
            L.setBefore(set - carry);
        }
    }

    L.moveFront();
    num = L.peekNext();
    if (num > base) {
        carry = num / base;
        L.setAfter(num % base);
        L.insertBefore(carry);
    }

    if (L.front() < 0) {
        normalizeList(L);
    }

    int temp = sign;
    int foundNonZero = false;
    while (!foundNonZero && L.position() < L.length()) {
        if (L.peekNext() != 0) {
        foundNonZero = true;
        return temp;
        } else {
        sign = 0;
        }
        L.moveNext();
    }

    return sign;
}


// shiftList()
// Prepends p zero digits to L, multiplying L by base^p. Used by mult().
void shiftList(List& L, int p){
    L.moveBack();
    for (int i = 0; i < p; i++){
        L.insertAfter(0);
    }
}


// scalarMultList()
// Multiplies L (considered as a vector) by m. Used by mult().
void scalarMultList(List& L, ListElement m){
    if (m != 1) {
        L.moveFront();
        while (L.position() < L.length()) {
            ListElement x = L.moveNext();
            if (x == 0)
                continue;
            L.eraseBefore();
            L.insertBefore(x * m);
        }
    }
}


// Class Constructors & Destructors ----------------------------------------

// BigInteger()
// Constructor that creates a new BigInteger in the zero state: 
// signum=0, digits=().
BigInteger::BigInteger(){
    signum = 0;
    digits = List();

}


// BigInteger()
// Constructor that creates a new BigInteger from the long value x.
BigInteger::BigInteger(long x){
    // Convert the long value to a string, Call the existing constructor with the string value
    std::string s = std::to_string(x);
    *this = BigInteger(s);
}


// BigInteger()
// Constructor that creates a new BigInteger from the string s.
// Pre: s is a non-empty string consisting of (at least one) base 10 digit
// {0,1,2,3,4,5,6,7,8,9}, and an optional sign {+,-} prefix.
BigInteger::BigInteger(std::string s){
    ListElement x;
    long n = s.length();
    int p = power;
    int r, i;
    // Check if string is empty and throw an error
    if (n == 0) {
        throw std::invalid_argument("BigInteger: Constructor: empty string");
    }

    int sign = 1;
    if (s[0] == '-') {
        sign = -1;
        s.erase(0, 1);
        n = s.length();
    } else if (s[0] == '+') {
        sign = 1;
        s.erase(0, 1);
        n = s.length();
    }else{
        sign = 1;
    }

    // Check if the string is now empty or contains non-numeric characters and throw an error
    while (n > 1 && s[0] == '0') {
        s.erase(0, 1);
        n = s.length();
    }

    if (n == 1 && s[0] == '0') {
        signum = 0;
    }
    
    for (char c : s) {
        if (!std::isdigit(c)) {
            throw std::invalid_argument("BigInteger: Constructor: non-numeric string");
        }
    }

    digits = List();
    
    // If the first char of "s" is not '0'
    if (s[0] != '0') {
        r = n % p;
        
        // Iterate over "i" starting at the length of string "s" subtracted by the power
        for (i = n - p; i >= 0; i -= p) {
            std::string substr = s.substr(i, p);
            x = std::stol(substr);
            digits.insertAfter(x);
        }
    
        if (r > 0) {
            std::string substr = s.substr(0, r);
            x = std::stol(substr);
            digits.insertAfter(x);
        }
    }
    // Set the sign
    signum = (digits.length() > 0) ? sign : 0;
}



// BigInteger()
// Constructor that creates a copy of N.
BigInteger::BigInteger(const BigInteger& N){
    signum = N.signum;
    digits = N.digits;
}

// Optional Destuctor
// ~BigInteger()
// ~BigInteger();


// Access functions --------------------------------------------------------

// sign()
// Returns -1, 1 or 0 according to whether this BigInteger is positive, 
// negative or 0, respectively.
int BigInteger::sign() const{
    return this->signum;
}


// compare()
// Returns -1, 1 or 0 according to whether this BigInteger is less than N,
// greater than N or equal to N, respectively.
int BigInteger::compare(const BigInteger& N) const{
    int results = 0;
    List L = digits;
    List R = N.digits;

    if (sign() > N.sign())
        results = 1;
    else if (sign() < N.sign())
        results = -1;
    else if (L.length() < R.length())
        results = -1;
    else if (L.length() > R.length())
        results = 1;
    else {
        L.moveFront();
        R.moveFront();

        while (L.position() < L.length()) {
            ListElement left = L.moveNext();
            ListElement right = R.moveNext();

            if (left < right) {
                results = -1;
                break;
            } else if (left > right) {
                results = 1;
                break;
            }
        }
    }

    return results;
    
}

// Manipulation procedures -------------------------------------------------

// makeZero()
// Re-sets this BigInteger to the zero state.
void BigInteger::makeZero(){
    digits.clear();
    signum = 0;

}



// negate()
// If this BigInteger is zero, does nothing, otherwise reverses the sign of 
// this BigInteger positive <--> negative. 
void BigInteger::negate(){
    signum = -1*signum;
}


// BigInteger Arithmetic operations ----------------------------------------

// add()
// Returns a BigInteger representing the sum of this and N.
BigInteger BigInteger::add(const BigInteger& N) const{
    List A,B,C;
    BigInteger result;
    A = this->digits;
    B = N.digits;
    int sgn1 = this->signum;
    int sng2 = N.signum;

    if(sgn1 == 0 && sng2 != 0){
        result.digits = B;
        result.signum = sng2;
        return result;
    }
    if(sgn1 != 0 && sng2 == 0){
        result.digits = A;
        result.signum = sgn1;
        return result;
    }
    if(sgn1 == 0 && sng2 == 0){
        return result;
    }

    //SumList for all possible addition of BigInts, (+)+(-), (+)+(+), etc..
    if(sgn1 == 1 && sng2 == 1){
        sumList(C,A,B,sng2);
    }else if(sgn1 == 1 && sng2 == -1){
        sumList(C,A,B,sng2);

    }else if(sgn1 == -1 && sng2 == 1 ){
        sumList(C,B,A,sgn1);

    }else if(sgn1 == -1 && sng2 == -1){
        sumList(C,A,B,1);
        negateList(C);
    }
    
    //return results appended onto List C
    result.signum = normalizeList(C);
    result.digits = C;
    return result;
}



// sub()
// Returns a BigInteger representing the difference of this and N.
BigInteger BigInteger::sub(const BigInteger& N) const{
    BigInteger A = BigInteger(N);
    A.negate();
    return add(A);
}


// mult()
// Returns a BigInteger representing the product of this and N. 
BigInteger BigInteger::mult(const BigInteger& N) const{
    BigInteger result, temp;
    int sign;
    List A = digits;
    List B = N.digits;
    int sgn1 = signum;
    int sgn2 = N.signum;
    int move = 0;
    long mult_val;
    temp.signum = sgn1;

    if (sgn1 == 0 || sgn2 == 0) {
        return result;
    }

    if (sgn1 == -1 && sgn2 == -1) {
        sign = 1;
    }
    else if (sgn1 == -1 && sgn2 == 1) {
        sign = -1;
    }
    else if (sgn1 == 1 && sgn2 == -1) {
        sign = -1;
    }
    else if (sgn1 == 1 && sgn2 == 1) {
        sign = 1;
    }

    B.moveBack();
    while (B.position() > 0) {
        temp.digits = A;
        temp.signum = 1;
        result.signum = 1;
        shiftList(temp.digits, move);
        mult_val = B.peekPrev();
        scalarMultList(temp.digits, mult_val);
        result = result + temp;
        result.signum = normalizeList(result.digits);
        move++;
        B.movePrev();
    }
    result.signum = sign;
    return result;
}






// Other Functions ---------------------------------------------------------

// to_string()
// Returns a string representation of this BigInteger consisting of its
// base 10 digits. If this BigInteger is negative, the returned string 
// will begin with a negative sign '-'. If this BigInteger is zero, the
// returned string will consist of the character '0' only.
std::string BigInteger::to_string(){
    
    std::string s = "";

    if (signum == 0) {
        return "0";
    }

    if (signum == -1) {
        s += "-";
    }

    ListElement x;
    std::string temp;

    digits.moveFront();
    while (digits.position() < digits.length()) {
        if(digits.position() != 0){
            x = power - std::to_string(digits.peekNext()).length();
            for(int i = 0; i < x; i++){
                temp+= "0";
            }
        }       
        temp += std::to_string(digits.peekNext());
        digits.moveNext();
    }
    
    auto pos = temp.find_first_not_of('0');
    if (pos != std::string::npos) {
        // Append the substring starting from the first non-zero digit
        s += temp.substr(pos);
    } else {
        // If all digits are zero, append '0' to the result
        s += '0';
    }

    return s;

}

// Overriden Operators -----------------------------------------------------

// operator<<()
// Inserts string representation of N into stream.
std::ostream& operator<<( std::ostream& stream, BigInteger N ){
   return stream << N.to_string();
}

// operator==()
// Returns true if and only if A equals B. 
bool operator==( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) == 0;

}

// operator<()
// Returns true if and only if A is less than B. 
bool operator<( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) < 0;
}

// operator<=()
// Returns true if and only if A is less than or equal to B. 
bool operator<=( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) <= 0;

}

// operator>()
// Returns true if and only if A is greater than B. 
bool operator>( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) > 0;
}

// operator>=()
// Returns true if and only if A is greater than or equal to B. 
bool operator>=( const BigInteger& A, const BigInteger& B ){
   return A.compare(B) >= 0;
}

// operator+()
// Returns the sum A+B. 
BigInteger operator+( const BigInteger& A, const BigInteger& B ){
    return A.add(B);
}

// operator+=()
// Overwrites A with the sum A+B. 
BigInteger operator+=( BigInteger& A, const BigInteger& B ){
    A = A.add(B);
    return A;
 
}

// operator-()
// Returns the difference A-B. 
BigInteger operator-( const BigInteger& A, const BigInteger& B ){
   return A.sub(B);
    
}

// operator-=()
// Overwrites A with the difference A-B. 
BigInteger operator-=( BigInteger& A, const BigInteger& B ){
    A = A.sub(B);
    return A;

}

// operator*()
// Returns the product A*B. 
BigInteger operator*( const BigInteger& A, const BigInteger& B ){
    return A.mult(B);

}

// operator*=()
// Overwrites A with the product A*B. 
BigInteger operator*=( BigInteger& A, const BigInteger& B) {
    A = A.mult(B);
    return A;
}