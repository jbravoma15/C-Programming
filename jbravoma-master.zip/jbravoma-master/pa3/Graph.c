/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa3                  *
************************/

#include "Graph.h"
#include <stdlib.h>
#include <stdio.h>


typedef enum { WHITE, GRAY, BLACK } Color;

typedef struct GraphObj {
    List *adj;  
    int *color;      
    int *parent;     
    int *discover;   
    int order;       
    int size;        
    int *finish;
    int time;    
} GraphObj;



// Constructors-Destructors
Graph newGraph(int n){
    Graph G = malloc(sizeof(GraphObj));
    G->adj = calloc(n+1, sizeof(List));
    G->color = calloc(n+1, sizeof(int));
    G->parent = calloc(n+1, sizeof(int));
    G->discover = calloc(n+1, sizeof(int));
    G->finish = calloc(n+1, sizeof(int));
    G->order = n;
    G->size = 0;
    G->time = 0;
    for (int i = 1; i <= n; i++) {
        G->adj[i] = newList();
        G->color[i] = 0;
        G->parent[i] = NIL;
        G->discover[i] = UNDEF;
        G->finish[i] = UNDEF;  // adding Discover and finish 
    }
    return G;

}


void freeGraph(Graph* pG){
    if (pG != NULL && *pG != NULL) {
        int n = (*pG)->order;

        for (int i = 1; i <= n; i++){
            freeList(&((*pG)->adj[i]));
        }

        free((*pG)->adj);
        free((*pG)->color);
        free((*pG)->parent);
        free((*pG)->discover); //add in discover
        free((*pG)->finish); // add in finish
        free(*pG);

        *pG = NULL;
    }

}


// Access functions
int getOrder(Graph G){  // Count the number of vertices in the Graph, return NIL if graph has no vertices 
    if (G == NULL){
        return NIL;
    }
    return G->order;

}

int getSize(Graph G){ //find the number of edges in the grpah, return NIL if graph is invalid 
    if (G == NULL){
       return NIL;
    }
    return G->size;

}


int getParent(Graph G, int u){ /* Pre: 1<=u<=n=getOrder(G) */
    if (G == NULL || u < 1 || u > getOrder(G)) { // find the parent vertez of the vertex u in the DFS forest
        return NIL;
    }
    return G->parent[u];

}

int getDiscover(Graph G, int u){ /* Pre: 1<=u<=n=getOrder(G) */
    if (G == NULL || u < 1 || u > getOrder(G)) {  // the time the vertex was discovered in the DFS forest
        return UNDEF;
    }
    return G->discover[u];
}

int getFinish(Graph G, int u){ /* Pre: 1<=u<=n=getOrder(G) */
    if (G == NULL || u < 1 || u > getOrder(G)) { // find the time the vertex was finished being searched 
        return UNDEF;
    }
    return G->finish[u];
}

// Manipulation procedures
void addArc(Graph G, int u, int v){ /* Pre: 1<=u<=n, 1<=v<=n */
//retrieve the Ajd list for vertex u and traverse through the graph until we find the correct position to insert v, else return graph
    if (G == NULL) {
        printf("Error: Graph is NULL\n");
        return;
    }
    if (u < 1 || u > getOrder(G) || v < 1 || v > getOrder(G)) {
        printf("Error: u or v is out of range\n");
        return;
    }
    List adjList = G->adj[u];
    moveFront(adjList);
    while (index(adjList) >= 0 && v > get(adjList)) {
        moveNext(adjList);
    }
    if (index(adjList) >= 0 && v == get(adjList)) {
        return;
    }
    if (index(adjList) >= 0) {
        insertBefore(adjList, v);
    } else {
        append(adjList, v);
    }
    G->size++;

}

void addEdge(Graph G, int u, int v){ /* Pre: 1<=u<=n, 1<=v<=n */
    if (G == NULL || u < 1 || u > getOrder(G) || v < 1 || v > getOrder(G)) {
        printf("addEdge() invalid arguments\n");
        exit(EXIT_FAILURE);
    }
    addArc(G, u, v);
    addArc(G, v, u);
    G->size--;        

}

void Visit(Graph G, List S, int x, int *time) { //private helper function, the second part of DFS from the Puesdo Code in the examples 
    G->discover[x] = ++(*time);
    G->color[x] = GRAY;
    moveFront(G->adj[x]);
    while (index(G->adj[x]) >= 0) {
        int v = get(G->adj[x]);
        if (G->color[v] == WHITE) {
            G->parent[v] = x;
            Visit(G, S, v, time);
        }
        moveNext(G->adj[x]);
    }
    G->color[x] = BLACK;
    G->finish[x] = ++(*time);
    prepend(S, x);
}

void DFS(Graph G, List S){ /* Pre: length(S)==getOrder(G) */
//traverse through the graph using DFS, until each node/vertex is found or discovered 
    if (length(S) != getOrder(G) || G == NULL || S == NULL ) {
        return;
    }
    int time = 0;
    int n = getOrder(G);
    for (int i = 1; i <= n; i++) {
        G->color[i] = WHITE;
        G->parent[i] = NIL;

    }
    moveFront(S);
    while (index(S) >= 0) {
        int u = get(S);
        if (G->color[u] == WHITE) {
            Visit(G, S, u, &time);
        }
        moveNext(S);
    }
    for (int i = 1; i <= n; i++) {
        deleteBack(S);
    }

}

// Other Functions
Graph transpose(Graph G){
// Create a new graph T with the same number of vertices as G, where every directed edge in G is reversed in T.
    Graph T = newGraph(getOrder(G));
    for (int u = 1; u <= getOrder(G); u++) {
        List L = G->adj[u];
        moveFront(L);
        while (index(L) != -1) {
            addArc(T, get(L), u);
            moveNext(L);
        }
    }
    return T;

}


Graph copyGraph(Graph G){
    //copy the graph onto a newly declared graph
    int n = getOrder(G);
    Graph copy = newGraph(n);

    for (int i = 1; i <= n; i++){
        List adjList = G->adj[i];
        moveFront(adjList);
        while (index(adjList) != -1){
            int v = get(adjList);
            addArc(copy, i, v);
            moveNext(adjList);
        }
    }

    return copy;

}


void printGraph(FILE* out , Graph G){  // Similar to Pa2 PrintGraph

    for(int i = 1; i <= G->order; i++) {
        fprintf(out, "%d:", i);
        moveFront(G->adj[i]);
        while(index(G->adj[i]) != -1) {
            fprintf(out, " %d", get(G->adj[i]));
            moveNext(G->adj[i]);
        }
        fprintf(out, "\n");
    }

}