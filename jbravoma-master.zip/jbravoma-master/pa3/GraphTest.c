/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa3                  *
************************/

#include <stdio.h>
#include <assert.h>

#include <stdlib.h>
#include "Graph.h"
#include "List.h"

int main(int argc, char const *argv[])
{
    int score =0;
    // Tesiting Constructors and Destructors 

    //NewGraph
    printf("Testing NewGraph\n");
    Graph A = newGraph(5);
    if(getOrder(A) == 5){
        printf("Test 1 Passed order is: %d\n", getOrder(A));
        score++;
    }else{
        printf("Test 1 Failed order is: %d\n", getOrder(A));
    }
    freeGraph(&A);

    Graph B = newGraph(0);
    if(getOrder(B) == 0){
        printf("Test 2 Passed order is: %d\n", getOrder(B));
        score++;
    }else{
        printf("Test 2 Failed order is: %d\n", getOrder(B));
    }
    freeGraph(&B);

    printf("\nNewGraph passed %d/2 tests \n",score);


    score = 0;
    //FreeGraph
    printf("\nTesting FreeGraph\n");

    Graph C = newGraph(5);
    freeGraph(&C); 
    if (C == NULL) {
        printf("Test 1 Passed: Graph is Free\n");
        score++;
    } else {
        printf("Test 1 Fail: Graph is not freed\n");
    }

    Graph D = newGraph(10);
    freeGraph(&D); 
    if (D == NULL) {
        printf("Test 2 Passed: Graph is Free\n");
        score++;
    } else {
        printf("Test 2 Fail: Graph is not freed\n");
    }

    printf("\nFreeGraph passed %d/2 tests \n",score);

    //Testing Access functions
    printf("\nTesting FreeGraph\n");
    score =0;
    Graph E = newGraph(5);
    int order = getOrder(E); 
    if(order == 5){
        printf("Test 1 Passed order is: %d\n", order);
        score++;
    }else{
        printf("Test 1 Failed order is: %d\n", order);
        }
    E = newGraph(100);
    order = getOrder(E);

    if(order == 100){
        printf("Test 2 Passed order is: %d\n", order);
        score++;
    }else{
        printf("Test 2 Failed order is: %d\n", order);
        }
    
    freeGraph(&E);

    printf("\nGetOrder passed %d/2 tests \n",score);


    //getsize
    printf("\nTesting GetSize\n");
    score =0;
    Graph F = newGraph(5);
    //testing add edge
    addEdge(F, 1, 2);
    addEdge(F, 2, 3);
    addEdge(F, 3, 4);
    int size = getSize(F); 
    if(size == 3){
        printf("Test 1 Passed size is: %d\n", size);
        score++;
    }else{
        printf("Test 1 Failed size is: %d\n", size);
        }
    //testing add edge
    addEdge(F, 4, 5);
    addEdge(F, 5, 1);
    size = getSize(F);
    if(size == 5){
        printf("Test 2 Passed size is: %d\n", size);
        score++;
    }else{
        printf("Test 2 Failed size is: %d\n", size);
    }
    freeGraph(&F);

    printf("\nGetSize passed %d/2 tests \n",score);

    //getParent

    printf("\nTesting GetParent\n");
    score = 0;
    Graph G = newGraph(10);
    List L = newList();

    //testing add edge
    addEdge(G, 6, 4);
    addEdge(G, 6, 3);
    addEdge(G, 4, 2);
    for (uint8_t i = 1; i <= 10; i++) {
      append(L, i);
    }
    //testing DFS
    DFS(G, L);
    printf("DFS implmeneted Sucessfully\n");
    if (getParent(G, 10) == NIL){
      printf("Test 1 Passed: Parent is NULL\n");
      score++;
    }else{
        printf("Test 1 Failed: Parent is not NULL\n");
        }
    if (getParent(G, 4) == 2){
        printf("Test 2 Passed: Parent is %d\n", getParent(G,4));
        score++;
    }else{
        printf("Test 2 Failed: Parent is %d\n", getParent(G, 4));
        }
  
    printf("\nGetParent passed %d/2 tests \n",score);

    freeGraph(&G);

    printf("\nTesting GetDiscover\n");
    score = 0;

    Graph H = newGraph(5);
    L = newList();

    //testing add edge
    addEdge(H, 1, 2);
    addEdge(H, 2, 3);
    addEdge(H, 3, 4);
    for (uint8_t i = 1; i <= 5; i++) {
      append(L, i);
    }

    DFS(H, L);
    printf("DFS implmeneted Sucessfully\n");

    int discover = getDiscover(H, 4);

    if (discover == 4){
        printf("Test 1 Passed: Discover is %d\n", discover);
        score++;
    }else{
        printf("Test 1 Failed: Discover is %d\n", discover);
    }
    discover = getDiscover(H, 3);
    if (discover == 3){
        printf("Test 2 Passed: Discover is %d\n", discover);
        score++;
    }else{
        printf("Test 2 Failed: Discover is %d\n", discover);
    }

    printf("\nGetDiscover passed %d/2 tests \n",score);

    freeGraph(&H);

    //getfinish

    printf("\nTesting GetFinish\n");
    score = 0;

    Graph I = newGraph(5);
    L = newList();

    //testing add edge
    addEdge(I, 1, 2);  
    addEdge(I, 2, 3);
    addEdge(I, 3, 4);
    addEdge(I, 4, 5);
    for (uint8_t i = 1; i <= 5; i++) {
        append(L, i);
        }
    //testing DFS
    DFS(I, L);
    int finish = getFinish(I, 4);

    if (finish == 7){
        printf("Test 1 Passed: Finish is %d\n", finish);
        score++;
    }else{
        printf("Test 1 Failed: Finish is %d\n", finish);
        }
    finish = getFinish(I, 3);
    if (finish == 8){
        printf("Test 2 Passed: Finish is %d\n", finish);
        score++;
    }else{
        printf("Test 2 Failed: Finish is %d\n", finish);
        }
    printf("\nGetFinish passed %d/2 tests \n",score);
    freeGraph(&H);

    //testing AddArc and Add edge
    printf("\nTesting AddArc\n");
    score = 0;

    Graph J = newGraph(5);
    L = newList();
    addArc(J, 1, 2);
    addArc(J, 1, 3);
    addArc(J, 2, 4);
    addArc(J, 3, 4);
    addEdge(J, 4, 5);
    if(J != NULL){
        printf("Test 1 Passed: Edge and Arc were added to graph\n");
        printGraph(stdout, J);
        score++;
    }else{
        printf("Test 1 Failed: Edge and Arc were not added to graph\n");
    }

    printf("\nArc and Edge passed %d/1 tests \n",score);
    freeGraph(&J);



    //test transpose
    printf("\nTesting Transpose\n");
    score = 0;

    Graph K = newGraph(5);
    addEdge(K, 1, 2);
    addEdge(K, 1, 4);
    addEdge(K, 2, 4);
    addEdge(K, 3, 1);
    addEdge(K, 3, 5);
    addEdge(K, 4, 3);
    addEdge(K, 5, 5);

    Graph T = transpose(K);
    if(T != NULL){
        printf("Test 1 Passed: Transpose was created\n");
        printGraph(stdout, T);
        score++;
    }else{
        printf("Test 1 Failed: Transpose was not created\n");
        }

    printf("\nTranspose passed %d/1 tests \n",score);

    freeGraph(&T);

    //test copygraph
    printf("\nTesting CopyGraph\n");
    score = 0;

    Graph M = newGraph(5);
    addEdge(M, 1, 2);
    addEdge(M, 1, 4);
    addEdge(M, 2, 4);
    addEdge(M, 3, 1);
    addEdge(M, 3, 5);

    Graph N = copyGraph(M);
    if(M != NULL){
        printf("Test 1 Passed: CopyGraph was created\n");
        printGraph(stdout, N);
        score++;
    }else{
        printf("Test 1 Failed: CopyGraph was not created\n");
        }

    printf("\nCopyGraph passed %d/1 tests \n",score);

    freeGraph(&M);

    freeList(&L);
    return 0;
}

