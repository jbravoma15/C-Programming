/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa3                  *
************************/

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include "Graph.h"

int main(int argc, char * argv[]) {
    int i, n, u, v, comp = 0;
    FILE *in, *out; 
    Graph G, T;
    List S;
    
    if (argc != 3) {
        printf("Usage: %s <input file> <output file>\n", argv[0]);
        exit(1);
    }

    in = fopen(argv[1], "r");
    if (in == NULL) {
        printf("Unable to open file %s for reading\n", argv[1]);
        exit(1);
    }

    out = fopen(argv[2], "w");
    if (out == NULL) {
        printf("Unable to open file %s for writing\n", argv[2]);
        exit(1);
    }

    fscanf(in, " %d", &n);

    // initialize a new graph with "n"
    G = newGraph(n);

    u = 1;
    v = 1;
    while (u != 0 || v != 0) {
        fscanf(in, " %d %d", &u, &v);
        if (u == 0 || v == 0) {
            break;
        }
        addArc(G, u, v);
    }
    fprintf(out, "Adjacency list representation of G: \n");
    printGraph(out, G);
    fprintf(out, "\n");

    S = newList();

    for (i = 1; i <= getOrder(G); i++) {
        append(S, i);
    }

    DFS(G, S);

    T = transpose(G);
    DFS(T, S);

    moveFront(S);
    while (index(S) != -1) {
        if (getParent(T, get(S)) == NIL) {
            ++comp;
        }
        moveNext(S);
    }

    fprintf(out, "G contains %d strongly connected components:", comp);

    // Move to the back of the list
    moveBack(S);
    comp = 0;
    // Loop over the list
    while(index(S) != -1){
        ++comp;
        fprintf(out, "\nComponent %d:", comp);
        u = 0;
	    while(true){
            ++u;
            if(getParent(T, get(S)) == NIL){
                break;
            }
            movePrev(S);
            if(index(S) == -1){
                moveFront(S);
                break;
            }
	    }  

	
        // Print the first vertex in the component
        fprintf(out, " %d", get(S));
        
        for(v = 0; v < u - 1; ++v){
            moveNext(S);
            fprintf(out, " %d", get(S));
        }

        // Move back to the start of the component
        for(v = 0; v < u; ++v){
            movePrev(S);
        }
    }
    fprintf(out, "\n");


    // free memory and close files 
    freeList(&S);
    freeGraph(&G);
    freeGraph(&T);

    fclose(in);
    fclose(out);

    return 0;
}

