/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa8                  *
************************/
#include <iostream>
#include <sstream>
#include <string>
#include <stdexcept>
#include "Dictionary.h"

using namespace std;

int main() {

   //Testing Dictionary
   Dictionary a;
   Dictionary b;
   Dictionary c;
   Dictionary d;

   //Testing SetVal
   cout << endl;

   cout << "------Tesiting SetVal------" << endl;

   a.setValue("Apple", 10);
   
   cout << "Values set to Dictionary a are:  "<< endl << a << endl;

   b.setValue("banana", 3);
   b.setValue("cherry", 28);
   
   cout << "Values set to Dictionary b are: " << endl << b << endl;

   c.setValue("pear", 21);
   c.setValue("orange", 12);
   c.setValue("strawberry", 80);

   cout << "Value set to Dictionary c are: " << endl << c << endl;

   //Testing Size 

   cout << "------Tesiting Size------" << endl;

   cout << "Size of a is: " << a.size() << endl;
   cout << "Size of b is: " << b.size() << endl;
   cout << "Size of c is: " << c.size() << endl;
   cout << "Size of d is: " << d.size() << endl;

   cout << endl;    

   //Testing Clear
   cout << "------Tesiting Clear------" << endl;

   a.clear();
   b.clear();
   c.clear();

   cout << "Size of a After Clear is: " << a.size() << endl;
   cout << "Size of b After Clear is: " << b.size() << endl;
   cout << "Size of c After Clear is: " << c.size() << endl;

   cout << endl;

   //Testing Contains 

   cout << "------Tesiting Contains------" << endl;
   a.setValue("pear", 21);
   a.setValue("orange", 12);
   a.setValue("strawberry", 80);

   if(a.contains("pear")){
      cout << "True: Dictionary A contains pear " << endl;
   }else{
      cout << "False: Dictionary A does not contain pear " << endl;
   }
   if(a.contains("orange")){
      cout << "True: Dictionary A contains orange " << endl;
   }else{
      cout << "False: Dictionary A does not contain orange " << endl;
   }
   if(a.contains("pinapple")){
      cout << "True: Dictionary A contains pinapple " << endl;
   }else{
      cout << "False: Dictionary A does not contain pinapple " << endl;
   }
   cout << endl;

   //Testing GetValue
   cout << "------Tesiting GetValue------" << endl;
   
   int num = 21; 
   if(a.getValue("pear") == num){
      cout << "Value of Dictionary A is:" << a.getValue("pear") << endl;
   }else{
      cout << "Value of Dictionary A is:" << a.getValue("pear") << endl;
   }  
   num = 12; 
   if(a.getValue("orange") == num){
      cout << "Value of Dictionary A is:" << a.getValue("orange") << endl;
   }else{
      cout << "Value of Dictionary A is:" << a.getValue("orange") << endl;
   }  
   cout << endl;

   //Testing HasCurrent 
   cout << "------Tesiting HasCurrent------" << endl;
   a.begin();
   if(a.hasCurrent()){
      cout << "True: Dictionary A has a current element " << endl;
   }else{
      cout << "False: Dictionary A does not have a current element " << endl;
   }
   if(d.hasCurrent()){
      cout << "True: Dictionary d has a current element " << endl;
   }else{
      cout << "False: Dictionary d does not have a current element " << endl;
   }

   cout << endl;

   //Testing CurrentKey, CurrentVal, Begin, and End
   cout << "------Testing CurrentKey, CurrentVal, Begin, and End------" << endl;

   Dictionary F;
   F.setValue("apple", 10);
   F.setValue("banana", 20);
   F.setValue("cherry", 30);
   F.setValue("durian", 40);
   F.setValue("elderberry", 50);
   F.setValue("fig", 60);
   F.setValue("grape", 70);
   F.setValue("honeydew", 80);
   F.setValue("kiwi", 90);
   F.setValue("lemon", 100);
   F.setValue("lime", 110);

   F.begin();
   std::string currKey = F.currentKey();
   cout << "Dictionary F:" << endl << F << endl;
   cout << "begin() of key is: " << currKey << endl;
   F.end();
   currKey = F.currentKey();
   cout << "End() of key is: " << currKey << endl;

   F.begin();
   int currVal = F.currentVal();
   cout << "Current Value at Begin() is: " << currVal << endl;

   F.end();
   currVal = F.currentVal();
   cout << "Current Value at End() is: " << currVal << endl;
   cout << endl;

   //Testing remove
   cout << endl << "------Testing Remove------" << endl;
   cout << "Testing remove(): Dictionary F:" << endl << F << endl;
   F.remove("banana");
   cout << "Testing remove(): Dictionary F after removing banana:" << endl << F << endl;


   //Testing Next
   cout << endl << "------Testing Next------" << endl;
   Dictionary H;
   H.setValue("peach", 11);
   H.setValue("pear", 12);
   H.setValue("plum", 13);
   H.setValue("grape", 14);
   H.setValue("blueberry", 15);
   H.setValue("cherry", 16);
   H.setValue("mango", 17);

   H.begin();
   cout << "Dictionary H:" << endl << H << endl;
   H.next();
   cout << "Moving to next() from begin() = " << H.currentKey() << endl;
   H.next();
   cout << "Moving to next() = " << H.currentKey() << endl;
   H.next();
   cout << "Moving to next() = " << H.currentKey() << endl;
   cout << endl;

   // Testing Prev
   cout << endl << "------Testing Prev------" << endl;
   H.end();
   cout << "Dictionary H:" << endl << H << endl;
   H.prev();
   cout << "Moving to prev() from end() = " << H.currentKey() << endl;
   H.prev();
   cout << "Moving to prev() = " << H.currentKey() << endl;
   H.prev();
   cout << "Moving to prev() = " << H.currentKey() << endl;
   cout << endl;

   //Testing To_String
   cout << "------Testing to_String------" << endl;
   cout << "Dictionary F to string: " << endl << F.to_string() << endl;
   cout << "Dictionary H to string: " << endl << H.to_string() << endl;

   // Testing Pre_string
   cout << "------Testing Pre_string------" << endl;
   cout << "Pre_string of Dictionary F: " << endl << F.pre_string() << endl;
   cout << "Pre_string of Dictionary H: " << endl << H.pre_string() << endl;

   // Testing Equals
   cout << "------Testing Equals------" << endl;
   cout << "Dictionary a and b are " << (a.equals(b) ? "equal" : "not equal") << endl;
   cout << "Dictionary b and c are " << (b.equals(c) ? "equal" : "not equal") << endl;


   cout<< endl << "------Testing Operators------" << endl;
   // Testing operator<<()
   Dictionary A;
   A.setValue("apple", 10);
   A.setValue("banana", 20);
   A.setValue("cherry", 30);
   cout << "Dictionary A: " << A << std::endl;

   Dictionary B;
   B.setValue("orange", 15);
   B.setValue("pear", 25);
   cout << "Dictionary B: " << B << std::endl;

   // Testing operator==()
   if (A == B) {
      cout << "Dictionary A is equal to Dictionary B" << std::endl;
   } else {
      cout << "Dictionary A is not equal to Dictionary B" << std::endl;
   }

   Dictionary C = B;
   cout << "Dictionary C: " << C << std::endl;

   if (B == C) {
      std::cout << "Dictionary B is equal to Dictionary C" << std::endl;
   } else {
      std::cout << "Dictionary B is not equal to Dictionary C" << std::endl;
   }

   // Testing operator=()
   Dictionary D;
   D.setValue("grape", 35);
   D.setValue("lemon", 45);
   cout << "Dictionary D (before assignment): " << D << std::endl;

   D = A;
   cout << "Dictionary D (after assignment): " << D << std::endl;

   return (EXIT_SUCCESS);
}
