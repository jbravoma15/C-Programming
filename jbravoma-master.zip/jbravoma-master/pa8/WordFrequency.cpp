/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa8                  *
************************/
#include "Dictionary.h"
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>

using namespace std;

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cout << "Usage: Order <input file> <output file>" << endl;
        return EXIT_FAILURE;
    }

    ifstream infile(argv[1]);
    ofstream outfile(argv[2]);

    if (!infile) {
        cout << "Error: Failed to open input file" << endl;
        return EXIT_FAILURE;
    }
    if (!outfile) {
        cout << "Error: Failed to open output file" << endl;
        return EXIT_FAILURE;
    }
    string line, key;
    string delim = " \t\\\"\',<.>/?;:[{]}|`~!@#$%^&*()-_=+0123456789";
    Dictionary wordFrequency;

    while (getline(infile, line)) {
        size_t len = line.length();
        size_t begin = line.find_first_not_of(delim, 0);
        
        while (begin != string::npos) {
            size_t end = line.find_first_of(delim, begin);
            if (end == string::npos) {
                end = len;
            }
            
            key = line.substr(begin, end - begin);
            transform(key.begin(), key.end(), key.begin(), ::tolower);
            
            if (wordFrequency.contains(key)) {
                wordFrequency.getValue(key)++;
            } else {
                wordFrequency.setValue(key, 1);
            }
            
            begin = line.find_first_not_of(delim, end + 1);
        }
    }
    outfile << wordFrequency << endl;

    wordFrequency.clear();
    infile.close();
    outfile.close();
    return EXIT_SUCCESS;
}

