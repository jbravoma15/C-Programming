/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa5                  *
************************/
#include<fstream>
#include<iostream>
#include<string>
#include"List.h"

using namespace std;

#define MAX_LEN 300

void shuffle(List& D) {
   List right;
   List left;
   D.moveFront();

   int length = D.length();
   int half= length / 2;

   for (int k = 0; k < half; k++) {
      right.insertBefore(D.moveNext());
   }

   for (int j = half; j < length; j++) {
      left.insertBefore(D.moveNext());
   }

   D.clear();
   right.moveFront();
   left.moveFront();

   while (right.position() != right.length() || left.position() != left.length()) {
      if (left.position() != left.length()) {
         D.insertBefore(left.moveNext());
      }
      if (right.position() != right.length()) {
         D.insertBefore(right.moveNext());
      }
   }
}

int main(int argc, char* argv[]) {
   if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <maximum deck size>" << std::endl;
        return 1;
    }

    int maxDeckSize = std::stoi(argv[1]);

    std::cout << "deck size       shuffle count" << std::endl;
    std::cout << "------------------------------" << std::endl;

    for (int n = 1; n <= maxDeckSize; n++) {
        List deck;
        for (int i = 0; i < n; i++) {
            deck.insertBefore(i);
        }

        int shuffleCount = 0;
        List originalOrder = deck;

        do {
            shuffle(deck);
            shuffleCount++;
        } while (!deck.equals(originalOrder));

      std::cout << n << "\t\t" << shuffleCount << std::endl;
    }

    return 0;
}
