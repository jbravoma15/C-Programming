/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa1                  *
************************/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "List.h"

#define MAX_LEN 160

int main(int argc, char *argv[]) {
    FILE *in, *out;
    char line[MAX_LEN];
    int count = 0;

    // check command line for correct number of arguments
    if (argc != 3) {
        printf("Usage: %s <input file> <output file>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // open input file for reading
    if ((in = fopen(argv[1], "r")) == NULL) {
        printf("Unable to read from file %s\n", argv[1]);
        exit(EXIT_FAILURE);
    }

    // open output file for writing
    if ((out = fopen(argv[2], "w")) == NULL) {
        printf("Unable to write to file %s\n", argv[2]);
        exit(EXIT_FAILURE);
    }

    // count number of lines in the input file
    while (fgets(line, MAX_LEN, in) != NULL) {
        count++;
    }

    // allocate memory for an array of strings, using malloc we can allocate the memory 
    // to represent our StringArray
    char **stringArray = malloc(count * sizeof(char*));
    for (int i = 0; i < count; i++) {
        stringArray[i] = malloc(MAX_LEN * sizeof(char)); // size of the array
    }

    // read input file and store each line in the array
    // create an indice for each new string in stringArray 

    rewind(in); // reset the pointer of the array to beginning of the file
    int indice = 0;
    while (fgets(line, MAX_LEN, in) != NULL) {
        strcpy(stringArray[indice], line);
        indice++;
    }

    // create a new List to store the newly arranged array
    List A = newList();
    append(A, 0);

    // rearranged the array using insertAfter()
    for (int i = 1; i < count; i++) {
        moveBack(A);
        char *string_i = stringArray[i];
        while (index(A) >= 0 && strcmp(string_i, stringArray[get(A)]) < 0) {
            movePrev(A);
        }
        if (index(A) < 0) {
            prepend(A, i);
        } else {
            insertAfter(A, i);
        }
    }

    // print the arranged array to the output file
    // Check using the TimeShare and Pull the txt file to make 
    //sure that the new array is printed
    moveFront(A);
    while (index(A) >= 0) {
        fprintf(out, "%s", stringArray[get(A)]);
        moveNext(A);
    }

    // free memory and close files
    // Exit the program

    for (int i = 0; i < count; i++) {
        free(stringArray[i]);
    }


    free(stringArray);
    freeList(&A);
    fclose(in);
    fclose(out);

    return 0;  
}

