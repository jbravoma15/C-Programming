/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa1                  *
************************/

#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<stdbool.h>
#include"List.h"



int main(int argc, char* argv[]){
 // Call each of the above functions at least once, exercising
 // every possible logical pathway through the function, including
 // error states.

    List L = newList();
    
    //testing Prepend 
    prepend(L, 1);
    prepend(L, 2);
    prepend(L, 3);
    prepend(L, 4);
    prepend(L, 5);

    List A = newList();
   
    //testing Prepend 
    prepend(A, 1);
    prepend(A, 2);
    prepend(A, 3);
    prepend(A, 4);
    prepend(A, 5);

    List C = NULL;

    List D = newList();
   
    //testing append 
    append(D, 1);
    append(D, 2);
    append(D, 3);
    append(D, 4);
    append(D, 5);

    //testing printlist
    printf("List L: ");
    printList(stdout, L); // output: List L: 5 4 3 2 1
    printf("\n");

    printf("List D: ");
    printList(stdout, D); // output: List L: 1 2 3 4 5
    printf("\n");

    //Test Length
    int Length1 = length(A); 

    int Length2 = length(L);

    if (Length1 == Length2){
        printf("Length of A: %d\n", Length1);       //output: Length of A: 5
        printf("Length of L: %d\n", Length2);      //output: Length of L: 5
    }

    //Test index

    int ind1 = index(A);
    int ind2 = index(D);
    int ind3 = index(L);



    if (ind1 != ind2 && ind1 == ind3){
        printf("index of A: %d\n", ind1);   //output: Index of L: -1
        printf("index of D: %d\n", ind2);   //output: Index of L: 0
        printf("index of L: %d\n", ind3);   //output: Index of L: -1
    }

    //Test Set
    List B = newList();
    append(B, 1);
    append(B, 2);
    append(B, 3);
    append(B, 4);
    append(B, 5);
    
    set(B, 5);

    if(get(B) == 5){
    printf("The Cusor is set to: %d \n",get(B)); //output The Cusor is set to: 5
    }
    set(B, 6);
    if(get(B) == 6){
    printf("The Cusor is set to: %d \n",get(B)); //output The Cusor is set to: 6
    }

    //Test Clear with printlist
    clear(B);
    if(index(B)== -1 && length(B) == 0){
        printf("List B is cleared \n"); //output The list is cleared
    }

    //testing Movefront and front
    moveFront(L);
    printf("Front of L: %d\n", front(L)); // output: Front of L: 5

    //testing MoveBack and back
    moveBack(L);
    printf("Back of L: %d\n", back(L)); // output: Back of L: 1

   
   //Testing MovePrev and get 
    movePrev(L);
    movePrev(L);
    printf("Current element of L: %d\n", get(L)); // output: Current element of L: 3
    

    //Testing MovePrev  
    C = copyList(A);
    printf("%s\n", equals(A,L)?"true":"false");    //Equals: True 
    printf("%s\n", equals(D,C)?"true":"false");     //Equals: False

    //testing Deletefront
    deleteFront(L);
    printf("List L after deleting front element: ");
    printList(stdout, L); // output: List L after deleting front element: 4 3 2 1
    printf("\n");

    //testing DeleteBack
    deleteBack(L);
    printf("List L after deleting back element: ");
    printList(stdout, L); // output: List L after deleting back element: 4 3 2
    printf("\n");


    //Test Delete 
    moveFront(D);    //Deleting 1
    delete(D);
    moveBack(D);
    if(index(D) == 3){
        printf("Front element was deleted, new list: "); // output Back element was deleted, new list: 2345
        printList(stdout, D);
        printf("\n");
    }


    //Testing insertBefore
    moveFront(L);
    moveNext(L);
    insertBefore(L, 6);
    printf("List L after inserting 6 before current element: ");
    printList(stdout, L); // output: List L after inserting 6 before current element: 4 6 3 2
    printf("\n");

    //Testing insertAfter
    moveNext(L);
    insertAfter(L, 7);
    printf("List L after inserting 7 after current element: ");
    printList(stdout, L); // output: List L after inserting 7 after current element: 4 6 3 2 7
    printf("\n");

    //Testing CopyList
    List M = copyList(L);
    printf("Copy of List L: ");
    printList(stdout, M); // output: Copy of List L: 4 6 3 2 7
    printf("\n");

    //One More copy list
    List G = copyList(D);
    printf("Copy of List D: ");
    printList(stdout, G); // output: Copy of List L: 5 4 3 2 1
    printf("\n");


    //Testing freeList
    freeList(&L);
    freeList(&M);

    


    return(EXIT_SUCCESS);
}
