/***********************
 * Jorge Bravo Martinez *
 * Jbravoma             *
 * Spring 2023          *
 * Pa7                  *
 ************************/

#include <iostream>
#include <string>
#include <stdexcept>
#include "Dictionary.h"

using namespace std;

int main() {
   // Testing Setval and size
   cout << endl << "------Testing SetVal and size------" << endl;
   Dictionary A;
   cout << endl;
   A.setValue("apple", 10);
   A.setValue("banana", 20);
   A.setValue("orange", 15);
   int size = A.size();
   cout << "Testing setValue(): " << endl << A << endl;
   cout << "Testing size(): Size of A = " << size << endl;
   cout << endl;

   // Testing contains
   cout << endl << "------Testing Containts------" << endl;

   Dictionary B;
   cout << endl;
   B.setValue("apple", 10);
   B.setValue("banana", 20);
   bool containsApple = B.contains("apple");
   bool containsGrape = B.contains("grape");

   cout << "Dictionary B is: " << endl << B << endl;
   cout << "Testing contains(): apple == apple is: " << containsApple << " (TRUE)" << endl;
   cout << "Testing contains(): banana == grape: " << containsGrape << " (NOT TRUE)" << endl;
   cout << endl;

   // Testing getValue
   cout << endl << "------Testing getValue------" << endl;

   Dictionary C;
   C.setValue("apple", 10);
   C.setValue("banana", 20);
   int appleValue = C.getValue("apple");
   int bananaValue = C.getValue("banana");

   cout << "Dictionary C:" << endl << C << endl;
   cout << "Testing getValue(): Value of apple is: " << appleValue << endl;
   cout << "Testing getValue(): Value of banana is: " << bananaValue << endl;
   cout << endl;

   // Testing hasCurrent
   cout << endl << "------Testing hasCurrent------" << endl;

   Dictionary D;
   Dictionary E;
   D.setValue("apple", 10);
   D.setValue("banana", 20);
   D.begin();
   E.begin();
   bool hasCurr = D.hasCurrent();
   bool hasEmpt = E.hasCurrent();

   cout << "Dictionary D:" << endl << D << endl;
   cout << "Dictionary E:" << endl << E << endl;

   cout << "Testing hasCurrent(): Has Current is: " << hasCurr << endl;
   cout << "Testing hasCurrent(): Has Current (Empty) is: " << hasEmpt << endl;
   cout << endl;

   // Testing CurrentKey, Begin, and End
   cout << endl << "------Testing CurrentKey, Begin, and End------" << endl;

   Dictionary F;
   F.setValue("apple", 10);
   F.setValue("banana", 20);
   F.setValue("cherry", 30);
   F.setValue("durian", 40);
   F.setValue("elderberry", 50);
   F.setValue("fig", 60);
   F.setValue("grape", 70);
   F.setValue("honeydew", 80);
   F.setValue("kiwi", 90);
   F.setValue("lemon", 100);
   F.setValue("lime", 110);

   F.begin();
   std::string currKey = F.currentKey();
   cout << "Dictionary F:" << endl << F << endl;
   cout << "Testing currentKey(): begin() of key is: " << currKey << endl;
   F.end();
   currKey = F.currentKey();
   cout << "Testing currentKey(): End() of key is: " << currKey << endl;

   // Testing CurrentValue
   cout << endl << "------Testing CurrentValue------" << endl;

   F.begin();
   int currVal = F.currentVal();
   cout << "Testing currentValue(): Current Value at Begin() is: " << currVal << endl;

   F.end();
   currVal = F.currentVal();
   cout << "Testing currentValue(): Current Value at End() is: " << currVal << endl;
   cout << endl;

   // Testing Clear
   cout << endl << "------Testing Clear------" << endl;
   cout << "Dictionary F:" << endl << F << endl;
   cout << "Size of F: " << F.size() << endl;
   cout << endl;
   F.clear();
   cout << "Testing Clear: Dictionary F after clear:" << endl << F << endl;
   cout << "Size of F: " << F.size() << endl;
   cout << endl;

   // Testing Remove
   cout << endl << "------Testing Remove------" << endl;
   F.setValue("apple", 10);
   F.setValue("banana", 20);
   F.setValue("orange", 15);
   cout << "Testing remove(): Dictionary F:" << endl << F << endl;
   F.remove("banana");
   cout << "Testing remove(): Dictionary F after removing banana:" << endl << F << endl;

   // Testing Next
   cout << endl << "------Testing Next------" << endl;
   Dictionary H;
   H.setValue("peach", 11);
   H.setValue("pear", 12);
   H.setValue("plum", 13);
   H.setValue("grape", 14);
   H.setValue("blueberry", 15);
   H.setValue("cherry", 16);
   H.setValue("mango", 17);

   H.begin();
   cout << "Testing next(): Dictionary H:" << endl << H << endl;
   H.next();
   cout << "Testing next(): Moving to next() from begin() = " << H.currentKey() << endl;
   H.next();
   cout << "Testing next(): Moving to next() = " << H.currentKey() << endl;
   H.next();
   cout << "Testing next(): Moving to next() = " << H.currentKey() << endl;
   cout << endl;

   // Testing Prev
   cout << endl << "------Testing Prev------" << endl;
   H.end();
   cout << "Testing prev(): Dictionary H:" << endl << H << endl;
   H.prev();
   cout << "Testing prev(): Moving to prev() from end() = " << H.currentKey() << endl;
   H.prev();
   cout << "Testing prev(): Moving to prev() = " << H.currentKey() << endl;
   H.prev();
   cout << "Testing prev(): Moving to prev() = " << H.currentKey() << endl;
   cout << endl;

   // Testing Operators
   cout << endl << "------Testing Operators------" << endl;
   A = H;
   cout << "Testing assignment operator: Copy of H to A:" << endl << A << endl;

   if (A == H) {
      cout << "A and H are equal" << endl;
   }

   return (EXIT_SUCCESS);
}
