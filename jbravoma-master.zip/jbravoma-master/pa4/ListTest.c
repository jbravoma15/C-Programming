/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa4                  *
************************/

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include"List.h"

int main(int argc, char* argv[]){
    List L = newList();
    int score = 0;

    //Testing Length()
    if (length(L) == 0 ){
        printf("Passed: Length of List is %d\n", length(L));
        score++;
        printf("Passed: Newlist was created\n");
        score++;
    }else{
        printf("Failed: Length of List is %d\n", length(L));
        printf("list was not created\n");
    }

    int a = 10, b = 20, c = 30;
    append(L, &a);
    append(L, &b);
    append(L, &c);

    //testing append, front(), back()
        if (*(int*)back(L) == 30 && *(int*)front(L) == 10 ){
            printf("Passed: front of list is %d\n", *(int*)front(L)); 
            score++;
            printf("Passed: back of list is %d\n", *(int*)back(L));
            score++;
            printf("Passed: append list functions properly\n");
            score++;
        }else{
            printf("Failed: front of list is %d\n", *(int*)front(L));
            printf("Failed: back of list is %d\n", *(int*)back(L));
            printf("Failed: Append did not function properly\n");
        }


    //Testing moveFront(, Index(), and Get() 
    moveFront(L);
    int g = *(int*)get(L);
    if(g == 10 && index(L) == 0){
        printf("Passed: index of list is %d\n", index(L));
        score++;
        printf("Passed: current pointer is %d\n",g); 
        score++;
        printf("Passed: List cursor was moved to front\n");
        score++;
    }else{
        printf("Failed: index of list is %d\n", index(L));
        printf("Failed: current pointer is %d\n",g);
        printf("Failed: List cursor was not moved to front\n");
    }

    List A = newList();
    prepend(A, &a);
    prepend(A, &b);
    prepend(A, &c);

    moveBack(A);
    //testing prepend() and moveBack()
    if (*(int*)back(A) == 10 && *(int*)front(A) == 30 ){
            printf("Passed: prepend list functions properly\n");
            score++;
            printf("Passed: moveBack work, pointer is %d\n", *(int*)back(A));
            score++;
    }else{
        printf("Failed: front of list is %d\n", *(int*)front(A));
        printf("Failed: back of list is %d\n", *(int*)back(A));
        printf("Failed: Append did not function properly\n");
    }

    int d = 11, e = 17;

    //testing insertBefore(), insertAfter(), moveNext(), and movePrev()
    insertAfter(A, &d);
    insertBefore(A, &e);

    if (*(int*)back(A) == 11){
        printf("Passed: insertAfter has inserted %d\n",*(int*)back(A));
        score++;
        }else{
            printf("Failed: insertAfter does not function properly\n");
    }
    movePrev(A);
    if (*(int*)get(A) == 17){
        printf("Passed: insertBefore has inserted %d\n",*(int*)get(A));
        score++;
        printf("Passed: MovePrev moved the pointer to previous element\n");
        score++;

        }else{
            printf("Failed: inserBefore does not work properly\n");

    }

    movePrev(A);
    moveNext(A);
    moveNext(A);

    if (*(int*)get(A) == 10){
        printf("Passed: moveNext moves pointer to next element\n");
        score++;
    }else{
        printf("Failed: moveNext does not work properly\n");
    }

    //testing clear, delete, set, deleteFront, and DeleteBack, 

    
    deleteFront(A);
    moveFront(A);

    if (*(int*)front(A) == 20){
        printf("Passed: deleteFront has deleted, new front is %d\n",*(int*)front(A));
        score++;
    }else{
        printf("Failed: deleteFront does not work properly\n");
    }

    
    moveBack(A);
    deleteBack(L);

    if (*(int*)back(L) == 20){
        printf("Passed: deleteBack has deleted, new Back is %d\n",*(int*)back(L));
        score++;
    }else{
        printf("Failed: deleteBack does not work properly\n");
        }

    int f = 16;
    set(A,&f);
    if (*(int*)get(A) == 16){
        printf("Passed: set has set the value to %d\n",*(int*)get(A) );
        score++;
        }else{
            printf("Failed: set does not work properly\n");
            }

    delete(A);
    

    if (length(A) != 4){
        printf("Passed: delete has deleted element\n");
        score++;
    }else{
        printf("Failed: delete does not work properly\n");
        }

    clear(A);

    if (length(A) == 0){
        printf("Passed: clear has cleared the list\n");
        score++;
    }else{
        printf("Failed: clear does not work properly\n");
        }
    
    freeList(&L);
    freeList(&A);
    
    if(L == NULL && A == NULL){
        printf("Passed: freeList has freed the list\n");
        score++;
    }else{
        printf("Failed: freeList does not work properly\n");
    }

    
    printf("ListTest passed %d/20 tests sucessfully\n", score);

    


    





    








   

  
   return(0);
}


