/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa4                  *
************************/

#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
#include"Matrix.h"
     
int main(){
   int n=100;
   int m=50;
   int score = 0;
   //testing NewMatrix
   Matrix A = newMatrix(n);
   Matrix B = newMatrix(m);
   Matrix C, D, E, F, G, H;

   

   //Testing Size 
   printf("Testing size function \n");

   if(size(A) == 100){
      printf("Test Passed: Size of Matrix A: %d\n", size(A));
      score++;
   }else{
      printf("Test Failed: Size of Matrix A: %d\n", size(A));
   }

   if(size(B) == 50){
      printf("Test Passed: Size of Matrix A: %d\n", size(B));
      score++;
   }else{
      printf("Test Failed: Size of Matrix A: %d\n", size(B));
   }

   printf("Size() passed %d/2 tests\n", score);

   //Testing NNZ
   printf("\nTesting NNZ function \n");
   score = 0;

   if(NNZ(A)==0){
      printf("Test Passed: NNZ of Matrix A: %d\n", NNZ(A));
      score++;
   }else{
      printf("Test Failed: NNZ of Matrix A: %d\n", NNZ(A));
   }

   //Testing ChangeEntry
   changeEntry(A, 1,3,7);
   changeEntry(A, 1,8,3);
   changeEntry(A, 1,5,4);
   changeEntry(A, 2,7,1);
   changeEntry(A, 2,9,8);
   changeEntry(A, 2,5,8);
   changeEntry(A, 3,3,7);
   changeEntry(A, 3,5,9);
   changeEntry(A, 3,4,10);

   if(NNZ(A)== 9){
      printf("Test Passed: NNZ of Matrix A: %d\n", NNZ(A));
      score++;
      printf("Test Passed: Entries of matrix were sucessfully changed\n");
      score++;
   }else{
      printf("Test Failed: NNZ of Matrix A: %d\n", NNZ(A));
      printf("Test Failed Entries were not changed\n");
   }

   printf("NNZ() and ChangeEntry() passed %d/3 tests\n",score);

   //Testing Equals 
   printf("\nTesting Equals function \n");
   score = 0;

   if(equals(A,B) == 0){
      printf("Test Passed: Equals Function \n");
      score++;
   }else{
      printf("Test Failed: Equals Function \n");
   }
   //Testing Copy 
   B = copy(A);
   if(equals(A,B) == 1){
      printf("Test Passed: Equals Function \n");
      score++;
      printf("Test Passed: Matrix was copied sucessfully\n");
      score++;
   }else{
      printf("Test Failed: Equals Function \n");
   }
   printf("Equals() and Copy() passed %d/3 tests\n",score);
   

   //Testign MakeZero 
   printf("\nTesting MakeZero function \n");
   score = 0;
   if(NNZ(A) == 9){
      printf("Number of Entries is: %d\n", NNZ(A));
   }
   makeZero(A);
   if(NNZ(A) == 0){
      printf("Test Passed: Number of Entries is: %d\n", NNZ(A));
      score++;
   }else{
      printf("Test Failed: MakeZero Function \n");
      }

   makeZero(B);
   if(NNZ(B) == 0){
      printf("Test Passed: Number of Entries is: %d\n", NNZ(A));
      score++;
   }else{
      printf("Test Failed: MakeZero Function \n");
      }

   printf("MakeZero() passed %d/2 test \n",score);
   
   

   //Testing ChangeEntry
   changeEntry(A, 1,3,7);
   changeEntry(A, 1,8,3);
   changeEntry(A, 1,5,4);
   changeEntry(A, 2,7,1);
   changeEntry(A, 2,9,8);
   changeEntry(A, 2,5,8);
   changeEntry(A, 3,3,7);
   changeEntry(A, 3,5,9);
   changeEntry(A, 3,4,10);

   B = copy(A);

   //Testing Transpose
   printf("\nTesting Transpose and PrintMatrix function \n");
   score = 0;

   C = transpose(A);

   if (!equals(C, B)){
      printf("Test Passed: The list was tranposed succesfully\n");
      score++;
      printf("Test Passed: PrintMatix functions properly\n");
      printMatrix(stdout, C);
      printf("\n");
      score++;
   }else{
      printf("Test for Transpose Failed\n");
   }

   printf("MakeZero() and PrintMatrix() passed %d/2 test \n",score);


   //Testing ScalarMult
   printf("\nTesting ScalarMult function \n");
   score = 0;

   G = copy(A);
   H = scalarMult(2, G);

   if (!equals(H, G) && equals(A, G) == 1){
      printf("Test Passed: ScalarMult Produced: \n");
      printMatrix(stdout, H);
      printf("\n");
      score++;
   }else{
         printf("Test for ScalarMult Failed\n");
         }

   printf("ScalarMult passed %d/1 test\n", score);

   //Testing Sum()
   printf("\nTesting Sum() function \n");
   score = 0;

   E = copy(A);
   G = scalarMult(2, E);
   F = sum(E, A);

   if( equals(F, G)){
      printf("Test Passed: Sum Produced: \n");
      printMatrix(stdout, F);
      printf("\n");
      score++;
   }else{
      printf("Test for Sum Failed\n");
   }
   printf("Sum passed %d/1 test\n", score);


   //Testing Diff
   printf("\nTesting Diff() function \n");
   score = 0;


   E = copy(A);
   G = copy(A);
   F = diff(E, G);

   if(NNZ(F) == 0){
      printf("Test Passed: Diff functions properly \n");
      score++;
   }else{
      printf("Test for Diff Failed\n");
   }

   E = copy(A);
   G = scalarMult(2,A);
   F = diff(G, E);

   if(equals(A,F)){
      printf("Test Passed: Diff functions properly \n");
      printMatrix(stdout, F);
      score++;
   }else{
      printf("Test for Diff Failed\n");
   }

   printf("Diff passed %d/2 test\n", score);



   //Testing Product()
   printf("\nTesting Product() function \n");
   score = 0;

   D = copy(A);
   E = copy(A);
   F = product(D, E);


   if(NNZ(F)== 6){
      printf("Test Passed: Product functions properly \n");
      printMatrix(stdout, F);
      score++;
   }else{
      printf("Test for Product Failed\n");
      }

   printf("Product() passed %d/1 test\n",score);
   printf("\n");



   freeMatrix(&A);
   freeMatrix(&B);
   freeMatrix(&C);
   freeMatrix(&D);
   freeMatrix(&E);
   freeMatrix(&F);
   freeMatrix(&G);
   freeMatrix(&H);

   return EXIT_SUCCESS;
}

