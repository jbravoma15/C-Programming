/***********************
* Jorge Bravo Martinez *
* Jbravoma             *
* Spring 2023          *
* Pa4                  *
************************/

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "Matrix.h"
#include <math.h>

typedef struct EntryObj *Entry;

typedef struct EntryObj {
    int col;
    double val;
} EntryObj;

typedef struct MatrixObj {
    int size;
    int NNZ;
    List *row;
} MatrixObj;


void freeEntry(Entry *pE) {
    if (pE != NULL && *pE != NULL) {
        free(*pE);
        *pE = NULL;
    }

}


Entry newEntry(int column, double value) {
    Entry E = malloc(sizeof(EntryObj));
    E->col = column;
    E->val = value;
    return E;
}



// newMatrix()
// Returns a reference to a new nXn Matrix object in the zero state.
Matrix newMatrix(int n){
    if (n < 1) {
        printf("Error: newMatrix() n must be at least 1\n");
        exit(EXIT_FAILURE);
    }
    

    Matrix M = malloc(sizeof(MatrixObj));
    M->size = n;
    M->NNZ = 0;
    M->row = malloc((n + 1) * sizeof(List));
    for (int i = 1; i <= n; i++) {
        M->row[i] = newList();
    }

    return M;
}


// freeMatrix()
// Frees heap memory associated with *pM, sets *pM to NULL.
void freeMatrix(Matrix* pM){
    if (pM != NULL && *pM != NULL) {
        makeZero(*pM);
        for (int i = 1; i <= (*pM)->size; i++) {
            freeList(&(*pM)->row[i]);
        }
        free((*pM)->row);
        free(*pM);
        *pM = NULL;
    }
}



// Access functions
// size()
// Return the size of square Matrix M.
int size(Matrix M){
    return M->size;
}


// NNZ()
// Return the number of non-zero elements in M.
int NNZ(Matrix M){
    return M->NNZ;
}


// equals()
// Return true (1) if matrices A and B are equal, false (0) otherwise.
int equals(Matrix A, Matrix B){
    if (A == NULL || B == NULL){
        return 0;
    }
    
    if (A->size != B->size) {
        return 0;
    }

    for (int i = 1; i <= A->size; i++) {
        List c = A->row[i];
        List d = B->row[i];
        moveFront(c);
        moveFront(d);
        while (index(c) >= 0 && index(d) >= 0) {
            Entry x = (Entry)get(c);
            Entry y = (Entry)get(d);

            if (x->col != y->col || x->val != y->val) {
                return 0;
            }
            moveNext(c);
            moveNext(d);
        }
        if (index(c) != index(d)) {
            return 0;
        }
    }
    
    return 1;

}

// Manipulation procedures
// makeZero()
// Re-sets M to the zero Matrix state.
void makeZero(Matrix M){
    if(M == NULL){
        printf("Error: makeZero() Matrix is NULL\n");
        exit(EXIT_FAILURE);
    }
    M->NNZ = 0;
    for (int i = 1; i <= M->size; i++) {
        clear(M->row[i]);
    }
    
}


// changeEntry()
// Changes the ith row, jth column of M to the value x.
// Pre: 1<=i<=size(M), 1<=j<=size(M)
void changeEntry(Matrix M, int i, int j, double x){
    if (M == NULL) {
        printf("Error: changeEntry() Matrix is NULL\n");
        exit(EXIT_FAILURE);
    }
    if (i > M->size || i < 1 || j > M->size || j < 1) {
        printf("Error: changeEntry() i or j out of range\n");
        exit(EXIT_FAILURE);
    }
    List L = M->row[i];
    Entry E = NULL;

    for (moveFront(L); index(L) >= 0; moveNext(L)) {
        E = (Entry) get(L);
        if (E->col >= j) {
            break;
        }
    }

    // Update, insert or delete the entry depending on the value of x
    if (E != NULL && E->col == j) {
        if (x == 0.0) {
            // Entry exists and x is zero, delete the entry
            delete(L);
            M->NNZ--;
            freeEntry(&E);
        } else {
            // Entry exists and x is non-zero, update the entry value
            E->val = x;
        }
    } else if (x != 0.0) {
        // Entry does not exist and x is non-zero, insert a new entry before E
        Entry newE = newEntry(j, x);
        if (index(L) < 0) {
            append(L, newE);
        } else {
            insertBefore(L, newE);
        }
        M->NNZ++;
    }
}



// Matrix Arithmetic operations
// copy()
// Returns a reference to a new Matrix object having the same entries as A.
Matrix copy(Matrix A){
    Matrix copy = newMatrix(size(A));
    Entry E;
    int i, col;
    double val;
    
    for (i = 1; i <= size(A); i++) {
        moveFront(A->row[i]);

        while (index(A->row[i]) >= 0) {
            E = (Entry) get(A->row[i]);
            col = E->col;
            val = E->val;

            if (val != 0) {
                append(copy->row[i], newEntry(col, val));
                copy->NNZ++;
            }
            moveNext(A->row[i]);
        }
        
    }

    return copy;
}



// transpose()
// Returns a reference to a new Matrix object representing the transpose
// of A.
Matrix transpose(Matrix A){
    Matrix T = newMatrix(size(A));
    Entry E;
    int i;
    double val;

    for (i = 1; i <= size(A); i++) {
        moveFront(A->row[i]);
        while (index(A->row[i]) >= 0) {
            E = (Entry) get(A->row[i]);
            int col = E->col;
            val = E->val;
            changeEntry(T, col, i, val);
            moveNext(A->row[i]);
        }
    }

    return T;

}

// scalarMult()
// Returns a reference to a new Matrix object representing xA.
Matrix scalarMult(double x, Matrix A){
    if (A == NULL) {
        printf("Error: ScalarMult() List is NULL\n");
        exit(EXIT_FAILURE);
    }
    Matrix M = copy(A); // create a copy of matrix A
    Entry E;

    for (int i = 1; i <= size(M); i++) {
        moveFront(M->row[i]); // move to the front of the current row

        while (index(M->row[i]) >= 0) {
            E = (Entry)get(M->row[i]); // get the current entry
            double val = x * E->val; // multiply the entry value by x
            changeEntry(M, i, E->col, val); // change the entry value in M
            moveNext(M->row[i]); // move to the next entry in the current row
        }
    }
    return M;
}

void vectorSum(List A, List B, List C, int sign) {
    if (A == NULL || B == NULL || C == NULL) {
        printf("Error: vectorSum() List is NULL\n");
        exit(EXIT_FAILURE);
    }
    double x, y, z;
    Entry a, b;

    // move to the front of both lists
    moveFront(A);
    moveFront(B);

    // iterate through the two lists as long as their indexes are greater than or equal to 0
    while (index(A) >= 0 && index(B) >= 0) {

        a = (Entry)get(A);
        b = (Entry)get(B);
        x = a->val;
        y = sign * b->val;
        z = x + y;
        // if the column of entry "a" equals "b's"
        if (a->col == b->col) {
            if (z != 0) {
                append(C, newEntry(a->col, z));
            }
            moveNext(A);
            moveNext(B);
        }
        // else if Entry "a's" column is less than "b's"
        else if (a->col < b->col) {
            append(C, newEntry(a->col, x));
            moveNext(A);
        }
        // else Entry "a's" column is greater than "b's"
        else {
            append(C, newEntry(b->col, y));
            moveNext(B);
        }
    }

    // iterate through the remaining elements of list A
    while (index(A) >= 0) {
        a = get(A);
        append(C, newEntry(a->col, a->val));
        moveNext(A);
    }

    // iterate through the remaining elements of list B
    while (index(B) >= 0) {
        b = get(B);
        append(C, newEntry(b->col, sign * b->val));
        moveNext(B);
    }
}


// sum()
// Returns a reference to a new Matrix object representing A+B.
// pre: size(A)==size(B)
Matrix sum(Matrix A, Matrix B){
   if (A == NULL || B == NULL) {
        printf("Error: sum() Matrix is NULL\n");
        exit(EXIT_FAILURE);    
   }
    if (A->size != B->size) {
        printf("Error: sum() Matrices have different sizes\n");
        exit(EXIT_FAILURE);
    }
    Matrix Add = newMatrix(A->size);

    if (equals(A, B)) {
        Add = scalarMult(2, A);

    }else{
        for (int i = 1; i <= A->size; i++) {
        vectorSum(A->row[i], B->row[i], Add->row[i], 1);
        Add->NNZ += length(Add->row[i]);
        }
    }
    return Add;
    
}



// diff()
// Returns a reference to a new Matrix object representing A-B.
// pre: size(A)==size(B)
Matrix diff(Matrix A, Matrix B){
    if (A == NULL || B == NULL) {
        printf("Error: diff() Matrix is NULL\n");
        exit(EXIT_FAILURE);    
   }
    if (size(A) != size(B)) {
        printf("Matrix Error: diff() called on matrices of different sizes\n");
        exit(EXIT_FAILURE);
    }

    Matrix Diff = newMatrix(size(A));

    if(A == B){
        return Diff;        
    }

    if (equals(A, B)) {
        
        return Diff;

    }

    for (int i = 1; i <= size(A); i++) {
        vectorSum(A->row[i], B->row[i], Diff->row[i], -1);
        Diff->NNZ += length(Diff->row[i]);
    }


    return Diff; 
}


double vectorDot(List A, List B) {
    
    double dotProduct = 0.0;
    Entry a = NULL, b = NULL;

    // move to the front of both lists
    moveFront(A);
    moveFront(B);

    while (index(A) >= 0 && index(B) >= 0) {
        a = get(A);
        b = get(B);

        if (a->col == b->col) {
            dotProduct += a->val * b->val;
            moveNext(A);
            moveNext(B);
        }
        else if (a->col < b->col) {
            moveNext(A);
        }
        else {
            moveNext(B);
        }
    }
    return dotProduct;
}


// product()
// Returns a reference to a new Matrix object representing AB
// pre: size(A)==size(B)
Matrix product(Matrix A, Matrix B){
    if (A == NULL || B == NULL) {
        printf("Error: product() Matrix is NULL\n");
        exit(EXIT_FAILURE);
    }
    if (size(A) != size(B)) {
        printf("Matrix Error: product() called on matrices of different sizes\n");
        exit(EXIT_FAILURE);
    }

    Matrix M = newMatrix(size(A));
    Matrix T = transpose(B);
    double dotProduct;

    for (int i = 1; i <= size(A); i++) {
        if (length(A->row[i]) == 0) {
            continue; 
        }
        for (int j = 1; j <= size(A); j++) {
            if (length(T->row[j]) == 0) {
                continue; 
            }
            dotProduct = vectorDot(A->row[i], T->row[j]);
            if (dotProduct != 0.0) {
                changeEntry(M, i, j, dotProduct);
            }
        }
    }

    freeMatrix(&T);

    return M;
}



// printMatrix()
// Prints a string representation of Matrix M to filestream out. Zero rows
// are not printed. Each non-zero row is represented as one line consisting
// of the row number, followed by a colon, a space, then a space separated
// list of pairs "(col, val)" giving the column numbers and non-zero values
// in that row. The double val will be rounded to 1 decimal point.
void printMatrix(FILE* out, Matrix M){
    Entry E;
    int cont;
    for (int i = 1; i <= size(M); i++) {
        cont = 0;
        moveFront(M->row[i]);
        if (index(M->row[i]) >= 0) {
            E = (Entry) get(M->row[i]);
            if (E != NULL) {
                fprintf(out, "%d: ", i);
                cont = 1;
            }
        }
        while (index(M->row[i]) >= 0) {
            E = (Entry) get(M->row[i]);
            if (E != NULL) {
                fprintf(out, "(%d, %.1f) ", E->col, E->val);
            }
            moveNext(M->row[i]);
        }
        if (cont == 1) {
            fprintf(out, "\n");
        }
    }
}

